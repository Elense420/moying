#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小说角色对话 · 写后回写闭环（设计方案升级四 / G8）

每章正文落盘后同轮执行，同步三处状态：
  1. `.novel_state/<书名>/cards/<角色>_<章>.json`  逐章角色状态卡（台词记录/句长统计/词汇命中）
  2. `追踪/上下文.md`                            当前章 + 状态修订+1
  3. `追踪/逐章记录/第N章.md`                     对话统计表（同日小节替换）

产物是**历史数据与审计输入**：用于趋势比较、差异报告和 novel-audit 对接，
不会自动成为下一章的生成规则。

用法：
  python scripts/commit_chapter.py <工作目录> --chapter-file <正文路径> [--book 书名]
"""

import os
import re
import sys
import glob
import json
import argparse
import datetime

QUOTE_PAIR = re.compile(r"[“「『]([^”」』]{1,100})[”」』]")
HAS_QUOTE = re.compile(r"[“”「」『』]")


def find_skill_root():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(here)


def load_characters(path):
    """读 characters.json 的 speech_signature（用于台词归属与禁用词命中）。"""
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f).get("characters", {})
    except Exception:
        return {}


def load_known_names(workdir):
    """采集已知角色名（用于说话人归属）：约束 00 七维卡 ### 标题 + characters.json 键。"""
    names = set()
    p00 = os.path.join(workdir, "约束", "00_七维角色卡清单.md")
    if os.path.exists(p00):
        with open(p00, "r", encoding="utf-8") as f:
            for m in re.finditer(r"^###\s+([^\s<（(]+)", f.read(), re.M):
                names.add(m.group(1).strip())
    return names


def extract_chapter_dialogue(text, known_names=None):
    """从正文抽取对话行并归属说话人。

    归属策略（两级）：① 优先在引号附近的叙述片段里匹配已知角色名（约束 00/characters.json），
    避免"他缓缓/了一个哈欠"式盲抓；② 回退到"XX说/道/问"正则。
    返回 {角色名: {"lines": [...], "count": N, "avg_len": F}}
    """
    known_names = sorted(known_names or [], key=len, reverse=True)  # 长名优先
    speakers = {}
    for raw in text.splitlines():
        ln = raw.strip()
        if not HAS_QUOTE.search(ln):
            continue
        quotes = QUOTE_PAIR.findall(ln)
        if not quotes:
            continue
        speaker = None
        # ① 已知角色名优先：该行出现已知名字 + 说话动词标记
        if known_names and re.search(r"(?:说|道|问|答|喊|笑|叹|开口|低声|压低声|喃喃)", ln):
            for name in known_names:
                if name in ln:
                    speaker = name
                    break
        # ② 回退正则（仅在结果像已知名/无名表为空时采用；叙述碎片归未归属）
        if not speaker:
            m = re.search(r"([一-龥]{2,4})(?:说|道|问|答|喊|笑|叹|低声|压低声)", ln)
            if m:
                cand = m.group(1)
                if not known_names or cand in known_names:
                    speaker = cand
                # 有已知名表时，正则碎片（"到了就知""那声音"）一律归未归属
        for q in quotes:
            entry = speakers.setdefault(speaker or "（未归属）",
                                        {"lines": [], "count": 0, "avg_len": 0.0})
            entry["lines"].append(q)
            entry["count"] += 1
    for name, e in speakers.items():
        lens = [len(x) for x in e["lines"]]
        e["avg_len"] = round(sum(lens) / len(lens), 1) if lens else 0
    return speakers


def write_cards(novel_state_dir, book, chapter_no, speakers, chars_cfg):
    """写 cards/<角色>_<章>.json。"""
    cards_dir = os.path.join(novel_state_dir, book, "cards")
    os.makedirs(cards_dir, exist_ok=True)
    written = 0
    for name, e in speakers.items():
        if name == "（未归属）":
            continue
        cfg = chars_cfg.get(name, {})
        sig = cfg.get("speech_signature", {})
        forbidden = sig.get("禁用词", [])
        hits = [w for w in forbidden if any(w in ln for ln in e["lines"])]
        card = {
            "voice_signature": {
                "口头禅": sig.get("口头禅", []),
                "禁用词": forbidden,
                "句长偏好": sig.get("句长偏好"),
                "称呼习惯": sig.get("称呼习惯", {}),
            },
            "this_chapter": {
                "appeared": True,
                "line_count": e["count"],
                "avg_quote_len": e["avg_len"],
                "forbidden_hits": hits,
                "note": "" if e["count"] else "正文出现姓名但未识别到台词标记",
            },
            "consistency": {"grade": None, "findings": []},
        }
        path = os.path.join(cards_dir, f"{name}_{chapter_no}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(card, f, ensure_ascii=False, indent=2)
        written += 1
    return written


def update_context(workdir, chapter_no, chapter_file):
    """滚动 追踪/上下文.md 的当前章与状态修订。幂等：当前章已是本章则不重复 +1。"""
    ctx = os.path.join(workdir, "追踪", "上下文.md")
    if not os.path.exists(ctx):
        return False
    with open(ctx, "r", encoding="utf-8") as f:
        text = f.read()
    if re.search(rf"当前章[：:]\s*第?{chapter_no}章", text):
        return "already"                     # 本章已登记过，不重复滚动
    text = re.sub(r"当前章[：:]\s*第?\d+章[^\n]*",
                  f"当前章：第{chapter_no}章（{datetime.date.today().isoformat()} 落盘）", text)
    m = re.search(r"状态修订[：:]\s*(\d+)", text)
    if m:
        text = re.sub(r"状态修订[：:]\s*\d+", f"状态修订：{int(m.group(1)) + 1}", text)
    else:
        text = text.rstrip() + f"\n\n状态修订：1\n"
    with open(ctx, "w", encoding="utf-8") as f:
        f.write(text)
    return True


def append_chapter_record(workdir, chapter_no, speakers):
    """把本章对话统计写进 追踪/逐章记录/第N章.md（无则建）。幂等：同日小节存在则替换内容。"""
    rec_dir = os.path.join(workdir, "追踪", "逐章记录")
    os.makedirs(rec_dir, exist_ok=True)
    rec = os.path.join(rec_dir, f"第{chapter_no}章.md")
    today = datetime.date.today().isoformat()
    lines = [f"\n## 对话回写（{today}）", "",
             "| 角色 | 台词数 | 平均句长 |", "|---|---|---|"]
    for name, e in sorted(speakers.items(), key=lambda x: -x[1]["count"]):
        if name == "（未归属）":
            continue
        lines.append(f"| {name} | {e['count']} | {e['avg_len']} |")
    body = "\n".join(lines) + "\n"

    if os.path.exists(rec):
        with open(rec, "r", encoding="utf-8") as f:
            text = f.read()
        sec_head = f"## 对话回写（{today}）"
        if sec_head in text:
            # 同日小节：替换内容（修正同一章的重复回写），不追加
            start = text.find(sec_head)
            tail = text[start:]
            m_next = re.search(r"\n## (?!对话回写)", tail)
            end = start + m_next.start() if m_next else len(text)
            text = text[:start].rstrip() + "\n" + body.strip() + "\n" + text[end:]
            with open(rec, "w", encoding="utf-8") as f:
                f.write(text)
            return "replaced"
        with open(rec, "a", encoding="utf-8") as f:
            f.write(body)
        return True
    with open(rec, "w", encoding="utf-8") as f:
        f.write(f"# 第{chapter_no}章\n{body}")
    return True


def main():
    ap = argparse.ArgumentParser(description="写后回写闭环")
    ap.add_argument("workdir", nargs="?", default=os.getcwd())
    ap.add_argument("--chapter-file", required=True)
    ap.add_argument("--book", default=None)
    args = ap.parse_args()

    workdir = os.path.abspath(args.workdir)
    chapter_file = os.path.abspath(args.chapter_file)
    if not os.path.exists(chapter_file):
        print(f"[错误] 正文不存在：{chapter_file}"); sys.exit(1)

    with open(chapter_file, "r", encoding="utf-8") as f:
        text = f.read()
    m = re.search(r"第(\d+)章", os.path.basename(chapter_file) + text[:200])
    chapter_no = m.group(1) if m else "0"

    # 定位 characters.json
    book = args.book
    if not book:
        ns = os.path.join(workdir, ".novel_state")
        subs = [d for d in os.listdir(ns) if os.path.isdir(os.path.join(ns, d))] if os.path.isdir(ns) else []
        book = subs[0] if subs else os.path.basename(workdir)
    chars = load_characters(os.path.join(workdir, ".novel_state", book, "characters.json"))
    known_names = load_known_names(workdir) | set(chars.keys())

    speakers = extract_chapter_dialogue(text, known_names)
    ns_dir = os.path.join(workdir, ".novel_state")
    os.makedirs(ns_dir, exist_ok=True)
    n_cards = write_cards(ns_dir, book, chapter_no, speakers, chars)
    ctx_ok = update_context(workdir, chapter_no, chapter_file)
    rec_ok = append_chapter_record(workdir, chapter_no, speakers)

    print(f"写后回写完成：第{chapter_no}章")
    print(f"  出声角色：{len([k for k in speakers if k != '（未归属）'])} 个"
          f"（未归属 {speakers.get('（未归属）', {}).get('count', 0)} 条）")
    print(f"  cards/：{n_cards} 张已刷新 → .novel_state/{book}/cards/")
    ctx_msg = {"already": "本章已登记，跳过滚动（幂等）", True: "已滚动", False: "未找到（跳过）"}.get(ctx_ok)
    print(f"  上下文.md：{ctx_msg}")
    rec_msg = {"already": "同日已写，跳过", "replaced": "同日小节已替换（幂等修正）",
               True: "已追加", False: "失败"}.get(rec_ok)
    print(f"  逐章记录：{rec_msg}")
    print(f"  报告：追踪已更新至第{chapter_no}章 · cards {n_cards} 张 · 差异报告待人工填")


if __name__ == "__main__":
    main()
