#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小说角色对话 · 网文TOP500 对话萃取批处理（设计方案 I7 / 蒸馏流程"方式 B"）

职责：把 `G:\\知识库\\网文TOP500` 某题材的抽样书目中的引号对话行 + 「黄-对白情绪」
标注段抽取、清洗、去重，按 题材 × 书目 落成原始样本批次文件（带 provenance），
供模型按 人物性格 × 关系 × 功能 聚类成《网文角色对话指导性文件》（指导文件一~九章）。

只读知识库，输出到独立目录；支持断点续跑（state json）。不做人格分类（那是模型层
聚类工作，不属于机械抽取）。

用法示例：
  python scripts/distill_dialogue.py --kb "G:\\知识库\\网文TOP500" --genre 都市职场 \
      --sample 12 --chapters 4 --out distill_out
  python scripts/distill_dialogue.py --kb "G:\\知识库\\网文TOP500" --all-genres \
      --sample 3 --limit-books 2 --out distill_out   # 冒烟测试（小量验证管线）

参数：
  --kb            知识库根目录
  --genre         题材目录名（可重复传多个；或 --all-genres 全部题材）
  --all-genres    遍历知识库全部题材目录
  --sample        N=每题材抽几本（默认 12；抽样确定性 seed=42）
  --chapters      N=每本取对话密度最高的 N 个卷文件（近似"对话最密 3~5 章"）
  --limit-books   测试用：每题材最多处理书目数（覆盖 --sample）
  --max-quotes    每卷文件最多保留的原始样本行数（默认 40）
  --out           输出目录（默认 <技能根>/distill_out）
  --state         断点文件（默认 <out>/.distill_state.json）
"""

import os
import re
import sys
import glob
import json
import random
import argparse
import datetime

QUOTE_PAIR = re.compile(r"[“「『]([^”」』]{1,100})[”」』]")
HAS_QUOTE = re.compile(r"[“”「」『』]")
# 允许保留的字符域：ASCII 可打印 + 通用标点 + CJK 标点 + CJK 统一表意 + 全角/半角形
_JUNK = re.compile(r"[^\x20-\x7e\u2000-\u206f\u3000-\u303f\u4e00-\u9fff\uff00-\uffef]")
# 元数据/占位文件名（不进正文卷候选）
META_NAME = re.compile(r"(占位|说明|进度|总表|索引|README|目录|MOC|书签|备注)", re.I)


def find_skill_root():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(here)


def clean_text(s):
    """去除源文件里的编码残留/控制字符（保留中文、全角标点与 ASCII），折叠连续空白。"""
    s = _JUNK.sub("", s)
    s = re.sub(r"[ \t]{2,}", " ", s)
    return s.strip()


def clean_line(line):
    s = clean_text(line)
    s = re.sub(r"^\s*#+\s*", "", s)          # 去标题前缀
    return s


def extract_quoted_lines(path):
    """抽取一个正文卷文件中的对话行（自动清洗编码残留）。

    返回 (rows, n_total, n_drop)：
      rows     [(行文本, 引号内字数), ...]（已清洗、已按垃圾占比丢弃坏行）
      n_total  引号候选行总数（用于判定文件是否编码降级）
      n_drop   因垃圾字符占比过高被丢弃的行数
    """
    rows = []
    n_total = n_drop = 0
    try:
        with open(path, "r", encoding="utf-8") as f:
            for raw in f:
                ln = clean_line(raw)
                if not ln or not HAS_QUOTE.search(ln):
                    continue
                if len(ln) < 6 or len(ln) > 300:
                    continue
                qlen = sum(len(m.group(1)) for m in QUOTE_PAIR.finditer(ln))
                if qlen < 4:
                    continue
                n_total += 1
                # 垃圾字符占比过高（源文件编码残留）的行丢弃
                if len(clean_text(raw)) < max(8, int(len(raw) * 0.5)):
                    n_drop += 1
                    continue
                rows.append((ln, qlen))
    except Exception:
        return [], 0, 0
    return rows, n_total, n_drop


def is_degraded_file(n_total, n_drop):
    """判定一个卷文件是否编码降级（源文件本身内容损坏，抽不出可靠样本）。"""
    return n_total >= 6 and n_drop / n_total > 0.5


def extract_yellow_sections(md_path):
    """取六色标注索引中「黄-对白情绪」段落的行（自动清洗；无引号则跳过）。"""
    rows = []
    try:
        with open(md_path, "r", encoding="utf-8") as f:
            text = f.read()
    except Exception:
        return rows
    # 找含"黄-对白情绪"或"黄-对白"或"黄 "的标题行位置
    lines = text.splitlines()
    in_section = False
    for raw in lines:
        if re.match(r"^#{1,4}\s+", raw) and ("黄" in raw):
            in_section = ("对白" in raw) or ("黄-对白" in raw) or ("黄-情绪" in raw)
            if in_section:
                continue
        if in_section:
            if re.match(r"^#{1,4}\s+", raw) and "黄" not in raw:
                break
            ln = clean_line(raw)
            if not ln or not HAS_QUOTE.search(ln) or not (6 <= len(ln) <= 300):
                continue
            if len(clean_text(raw)) < max(8, int(len(raw) * 0.5)):
                continue
            qlen = sum(len(m.group(1)) for m in QUOTE_PAIR.finditer(ln))
            if qlen < 4:
                continue
            rows.append((ln, qlen))
    return rows


def pick_densest(files, n, max_quotes):
    """按引号行密度排序取前 n 个健康卷文件，各抽最多 max_quotes 行（均匀间隔）。

    返回 (selected, stats)：
      selected [(卷文件, 抽取行列表), ...]
      stats    {"files": 候选卷数, "degraded": [降级卷文件相对路径], "kept": 保留行数}
    """
    scored = []
    degraded = []
    for f in files:
        rows, n_total, n_drop = extract_quoted_lines(f)
        if is_degraded_file(n_total, n_drop):
            degraded.append(f)
            continue
        if not rows:
            continue
        scored.append((len(rows), f, rows))
    scored.sort(key=lambda x: -x[0])
    selected, kept = [], 0
    for _, f, rows in scored[:n]:
        rows.sort(key=lambda x: -x[1])
        step = max(1, len(rows) // max_quotes)
        picked = [rows[i][0] for i in range(0, len(rows), step)][:max_quotes]
        selected.append((f, picked))
        kept += len(picked)
    return selected, {"files": len(files), "degraded": degraded, "kept": kept}


def find_book_parts(book_dir):
    """定位书目下的正文卷文件（剔除占位/索引/进度类元数据文件）与六色标注索引。"""
    parts = [p for p in glob.glob(os.path.join(book_dir, "**", "正文分卷", "*.md"), recursive=True)
             if not META_NAME.search(os.path.basename(p))]
    if not parts:  # 兼容无"正文分卷"子目录的布局：任何含大量引号的 md 按文件名兜底
        parts = [p for p in glob.glob(os.path.join(book_dir, "**", "*.md"), recursive=True)
                 if not META_NAME.search(os.path.basename(p))
                 and re.search(r"(正文|正文卷|分卷|第.*卷|ch|p\d{2,})", os.path.basename(p), re.I)]
    yellow = glob.glob(os.path.join(book_dir, "**", "标注索引_六色.md"), recursive=True)
    return parts, (yellow[0] if yellow else None)


def main():
    ap = argparse.ArgumentParser(description="网文TOP500 对话萃取批处理（方式B）")
    ap.add_argument("--kb", required=True, help="知识库根目录")
    ap.add_argument("--genre", action="append", default=[], help="题材目录名（可多次）")
    ap.add_argument("--all-genres", action="store_true", help="遍历全部题材目录")
    ap.add_argument("--sample", type=int, default=12, help="每题材抽样本数")
    ap.add_argument("--chapters", type=int, default=4, help="每本取对话最密的卷文件数")
    ap.add_argument("--limit-books", type=int, default=0, help="测试用每题材上限")
    ap.add_argument("--max-quotes", type=int, default=40, help="每卷最多样本行数")
    ap.add_argument("--out", default=os.path.join(find_skill_root(), "distill_out"))
    ap.add_argument("--state", default=None, help="断点文件路径")
    args = ap.parse_args()

    kb = os.path.abspath(args.kb)
    if not os.path.isdir(kb):
        print(f"[错误] 知识库不存在：{kb}")
        sys.exit(1)
    os.makedirs(args.out, exist_ok=True)
    state_path = args.state or os.path.join(args.out, ".distill_state.json")
    state = {"completed_books": []}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    done = set(state.get("completed_books", []))

    # 题材目录解析
    if args.all_genres:
        genres = sorted(d for d in os.listdir(kb)
                        if os.path.isdir(os.path.join(kb, d)) and not d.startswith(".")
                        and not d.startswith("00") and "索引" not in d)
    else:
        genres = [g for g in args.genre if os.path.isdir(os.path.join(kb, g))]
    if not genres:
        print("[错误] 未找到有效题材目录；--kb 下可用：",
              [d for d in os.listdir(kb) if os.path.isdir(os.path.join(kb, d))])
        sys.exit(1)

    rng = random.Random(42)
    coverage_rows = []          # [题材, 抽样书目, 成功书目, 降级书目, 保留样本行, 批次文件]
    for genre in genres:
        genre_dir = os.path.join(kb, genre)
        books = sorted(d for d in os.listdir(genre_dir)
                       if os.path.isdir(os.path.join(genre_dir, d)) and not d.startswith("."))
        sample = books if len(books) <= args.sample else rng.sample(books, args.sample)
        if args.limit_books:
            sample = sample[: args.limit_books]
        pending = [b for b in sample if os.path.join(genre, b) not in done]
        if not pending:
            print(f"[{genre}] 无待处理书目（已全部完成或已抽样）")
            continue

        batch_lines = [f"# {genre} · 对话原始样本批次",
                       "",
                       f"> 来源：{kb} ／ 抽样 {len(sample)} 本 × 每本对话最密 ≤{args.chapters} 卷 ／ "
                       f"每卷 ≤{args.max_quotes} 行",
                       "> 性质：**原始样本（只读抽取，逐条可回溯）**。已排除编码降级卷文件与占位/索引文件；"
                       "逐条去重。下一步由模型按 人物性格 × 关系 × 功能 聚类成《网文角色对话指导性文件》"
                       "对应章节；本文件不直接进约束文件夹。",
                       ""]
        seen_rows, book_ok, book_degraded, genre_kept = set(), 0, 0, 0
        genre_degraded_files = []
        for idx, book in enumerate(pending, 1):
            book_dir = os.path.join(genre_dir, book)
            parts, yellow = find_book_parts(book_dir)
            picked, stats = pick_densest(parts, args.chapters, args.max_quotes)
            yrows = extract_yellow_sections(yellow) if yellow else []
            rel = lambda p: os.path.relpath(p, kb).replace("\\", "/")   # noqa: E731
            new_rows = 0
            if picked or yrows:
                batch_lines.append(f"## 《{book}》")
                for f, lines in picked:
                    batch_lines.append(f"<!-- provenance: {rel(f)} -->")
                    for ln in lines:
                        if ln in seen_rows:
                            continue
                        seen_rows.add(ln)
                        new_rows += 1
                        batch_lines.append(f"- 原始样本：{ln}")
                if yrows:
                    batch_lines.append(f"<!-- provenance: {rel(yellow)} [黄-对白情绪] -->")
                    yrows.sort(key=lambda x: -x[1])
                    for ln, _ in yrows[: args.max_quotes]:
                        if ln in seen_rows:
                            continue
                        seen_rows.add(ln)
                        new_rows += 1
                        batch_lines.append(f"- 黄段样本：{ln}")
                batch_lines.append("")
            degraded_all = bool(parts) and bool(stats["degraded"]) and len(stats["degraded"]) == len(parts)
            if degraded_all or (not picked and not yrows and parts):
                book_degraded += 1
                genre_degraded_files.extend(rel(f) for f in stats["degraded"])
                batch_lines.append(f"<!-- 该书目卷文件编码降级或无可靠对话样本，已跳过："
                                   f"{len(stats['degraded'])} 卷降级 / 保留 {stats['kept']} 行 -->")
                batch_lines.append("")
            elif picked or yrows:
                book_ok += 1
                genre_kept += new_rows
            done.add(os.path.join(genre, book))
            print(f"[{genre}] {idx}/{len(pending)} 《{book}》：卷 {stats['files']} · 降级 "
                  f"{len(stats['degraded'])} · 选中 {len(picked)} · 黄段 {'有' if yrows else '无'}"
                  + (" · 该书目整体跳过" if degraded_all else ""))
        out_file = os.path.join(args.out, f"{genre}_对话原始样本.md")
        with open(out_file, "w", encoding="utf-8") as f:
            f.write("\n".join(batch_lines))
        coverage_rows.append([genre, len(sample), book_ok, book_degraded, genre_kept,
                              os.path.basename(out_file)])
        print(f"[{genre}] 批次文件：{out_file} · 成功 {book_ok} 本 / 降级跳过 {book_degraded} 本 · "
              f"保留样本 {genre_kept} 行")

    # 覆盖率报告（确保体裁齐全的可核查产物）
    if coverage_rows:
        cov_file = os.path.join(args.out, "coverage_report.md")
        lines = ["# 对话蒸馏 · 题材覆盖报告", "",
                 f"> 知识库：{kb} ／ 运行时间：{datetime.datetime.now().isoformat(timespec='minutes')} ／ "
                 f"抽样 seed=42 ／ 断点：{os.path.basename(state_path)}", "",
                 "| 题材 | 抽样书目 | 成功书目 | 降级/无样本书目 | 保留样本行 | 批次文件 |",
                 "|---|---|---|---|---|---|"]
        tot = [0, 0, 0]
        for g, s, ok, deg, kept, fname in coverage_rows:
            lines.append(f"| {g} | {s} | {ok} | {deg} | {kept} | `{fname}` |")
            tot[0] += ok
            tot[1] += deg
            tot[2] += kept
        lines.append(f"| **合计** | | **{tot[0]}** | **{tot[1]}** | **{tot[2]}** | |")
        lines += ["", "> 降级/无样本＝卷文件编码内容级损坏或抽不出可靠引号样本，需在抽样白名单人工剔除；",
                  "> 成功书目＝有 ≥1 个健康卷文件被选中并保留样本。", ""]
        with open(cov_file, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        print(f"覆盖率报告：{cov_file}")

    with open(state_path, "w", encoding="utf-8") as f:
        json.dump({"completed_books": sorted(done)}, f, ensure_ascii=False, indent=2)
    print(f"完成。断点已存：{state_path}（重跑自动跳过已完成书目）")


if __name__ == "__main__":
    main()
