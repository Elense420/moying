#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小说角色对话 · 资料文件夹初始化器（设计方案 I1/I2/I5）

v2 相对 v1 的变更：
  I1  修复角色识别缺陷 G1：`角色档案/*.md` 不再按"文件名剥离数字前缀"识别角色，
      改为 (a) 角色生态池目录结构、(b) 角色档案 md 的 `### <角色名>` 标题分节 /
      frontmatter characters 列表 两源采集；结构性名词黑名单过滤；名单回读确认。
  I2  幂等：已有 `约束/` 不覆盖手工内容；--mode update / 已存在时增量合并新增角色；
      --regen 才强制按扫描结果重建 00/04；初始化后探测并报告状态源接入情况。
  I5  --activate 登记技能激活标记（manifest / .novel_state / 约束 三选一落位），幂等。

用法：
  python scripts/init_constraints.py <工作目录> [--mode init|update] [--regen] [--prune-ghosts] [--yes] [--activate]
  不传工作目录则使用当前目录。

说明：
  - 01/02/03/05 由 references/ 母本复制进项目；00/04 是项目内生成文件（按角色扫描结果生成），
    不复制母本。references/七维角色卡清单.md 仅作填卡参考与范例供查阅。
  - 默认 init：00/04 不存在则按扫描结果创建，存在则走增量合并（见 --mode）。
  - 生成内容为观察记录与操作说明：角色语言相关字段记录已观察到的样本、来源与统计范围，
    供写作参考和差异报告使用，不作为角色必须遵守的规则；项目自行确认的规则写在项目内。
  - 交互确认仅在终端可用且未传 --yes 时出现（自动化安全）。
"""

import os
import re
import sys
import glob
import shutil
import argparse
import datetime
import json

# 技能 references 文件名 -> 约束文件夹目标文件名
# 00（七维卡）与 04（语言观察）是"项目生成文件"，不复制母本，由角色扫描结果生成；
# references/七维角色卡清单.md 仅作为填卡参考/范例供人查阅。
REFERENCE_MAP = [
    ("对话风格规则.md", "01_对话风格规则.md"),
    ("创作规范集成.md", "02_创作规范集成.md"),
    ("角色一致性检查清单.md", "03_角色一致性检查清单.md"),
    ("网文角色对话指导性文件.md", "05_网文对话语料.md"),
]

# 结构性名词黑名单：文件/章节主题词，绝不当作角色名（G1 根治的第三道闸）
BLACKLIST_NAMES = {
    "角色关系", "角色语言风格", "原著角色出场与剧情锚点", "关系索引", "情感记忆",
    "共享记忆", "项目MOC", "核心设定", "全书大纲", "卷纲", "细纲", "伏笔",
    "上下文", "章节摘要", "README", "总索引", "阅读进度", "总表", "追踪",
    "正文", "角色生态池", "世界规则", "创作规范", "角色档案", "大纲档案",
    "主角团", "原著主角团", "开场白", "人设", "人物卡", "剧情锚点", "出场",
}
# 名称后缀命中的也不当角色（档案/风格/锚点/索引/清单 等结构性词尾）
BLACKLIST_SUFFIXES = ("档案", "风格", "锚点", "索引", "清单", "模板", "总表", "池", "卡", "记录", "纲")


def find_skill_root():
    """脚本在 <skill>/scripts/ 下，父目录即技能根。"""
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(here)


def normalize_char_name(name):
    """角色名归一化：去书名号/空白/数字前缀残留。"""
    n = name.strip().strip("《》").strip()
    n = re.sub(r"^\d+[_\s、.．:：-]*", "", n)   # 去 "01_" 类残留
    n = re.sub(r"\s+", "", n)
    return n


def is_structural_name(name):
    """结构性名词判定（黑名单精确命中 / 词尾命中 / 组合与规则句特征 / 长度异常）。

    本判定只用于 md 标题类候选（源 B）；角色生态池目录名是用户显式建的卡，视为权威源，
    由调用方以 trusted=True 绕过（见 scan_characters）。
    """
    n = normalize_char_name(name)
    if not n:
        return True
    if n in BLACKLIST_NAMES:
        return True
    if any(n.endswith(s) for s in BLACKLIST_SUFFIXES):
        return True
    if len(n) > 14:                            # 角色名极少超过 14 字
        return True
    if re.search(r"^[0-9一二三四五六七八九十百千]+$", n):   # 纯序号/章节数字
        return True
    # 组合/概念/规则句标题特征（"路明非、楚子航、恺撒""锚点A：…""出场前四问"
    # "让角色把事情办坏一次" 等一律不当角色）
    if any(c in n for c in ("、", "：", ":", "—", "－", "“", "”", "‘", "’", "与")):
        return True
    if any(k in n for k in ("锚点", "四问", "写法", "字段", "主线", "群像", "依据", "属于",
                            "原则", "问题", "变化", "来源", "关系线", "IF", "镜头")):
        return True
    if "的" in n:
        return True
    if n[0] in ("让", "要", "把", "应", "别", "请", "勿", "不", "去", "每"):
        return True
    return False


def _strip_code_fences(text):
    """扫描标题前先剔除 ``` 围栏区，防把模板内的 `<角色名>` 当角色。"""
    return re.sub(r"```.*?```", "", text, flags=re.S)


def _scan_headings_from_md(path):
    """从 md 的 frontmatter characters 与 `###/#### <角色名>` 标题采集角色。"""
    names = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    except Exception:
        return names
    clean = _strip_code_fences(text)

    fm = re.search(r"^---\s*\n(.*?)\n---", clean, re.S | re.M)
    if fm:
        m = re.search(r"^characters\s*:\s*\[(.*?)\]", fm.group(1), re.S | re.M)
        if m:
            for item in re.findall(r"[\"']?([^\"',，\n]+)[\"']?", m.group(1)):
                n = normalize_char_name(item)
                if n and not is_structural_name(n):
                    names.append(n)
    for raw in re.findall(r"^#{3,4}\s+(.+?)\s*$", clean, re.M):
        heading = raw.strip()
        if heading.startswith("<") or heading.startswith("（") or heading.startswith("("):
            continue
        n = normalize_char_name(heading)
        if n and not is_structural_name(n):
            names.append(n)
    return names


def scan_characters(workdir):
    """两源采集出声角色（生态池优先、档案标题补充），去重后返回有序名单。

    源 A：`**/角色生态池/<书名>/<角色名>/` 内含 README.md 或 01_persona_core.md 的目录；
    源 B：`**/角色档案/*.md` 的 ### 标题分节 + frontmatter characters。
    去重规则：归一化全等 或 互为子串（保留先入的更长名，如"上杉绘梨衣"覆盖"绘梨衣"）。
    """
    names, seen = [], set()

    def try_add(candidate, trusted=False):
        n = normalize_char_name(candidate)
        if not n:
            return False
        if not trusted and is_structural_name(n):
            return False
        for e in seen:
            if n == e or n in e or e in n:     # 互为子串视为同一角色
                return False
        seen.add(n)
        names.append(candidate.strip().strip("《》"))
        return True

    # 源 A：角色生态池（两级目录：<书名>/<角色名>）——用户显式建卡，trusted 权威源
    for pool in glob.glob(os.path.join(workdir, "**", "角色生态池"), recursive=True):
        if not os.path.isdir(pool):
            continue
        for novel_dir in os.listdir(pool):
            if novel_dir.startswith("."):
                continue
            novel_path = os.path.join(pool, novel_dir)
            if not os.path.isdir(novel_path):
                continue
            for char_dir in os.listdir(novel_path):
                if char_dir.startswith("."):
                    continue
                char_path = os.path.join(novel_path, char_dir)
                if not os.path.isdir(char_path):
                    continue
                if (os.path.exists(os.path.join(char_path, "README.md")) or
                        os.path.exists(os.path.join(char_path, "01_persona_core.md"))):
                    try_add(char_dir, trusted=True)

    # 源 B：角色档案 md 的标题分节 / frontmatter
    for md in glob.glob(os.path.join(workdir, "**", "角色档案", "*.md"), recursive=True):
        for n in _scan_headings_from_md(md):
            try_add(n)

    return names


# ---------------------------------------------------------------- 生成模板

def _dim_block(name):
    return f"""### {name}
- **D1 身份与核心矛盾**：（身份/阵营/职责；想保护或得到什么、受什么限制；当前弧光位置。附章节或场景证据）
- **D2 语言观察与近期样本**：（把已观察到的表达记在这里：近期语言样本、常见表达倾向、称呼与关系变化、
  说话节奏的统计范围、回避或改口或停顿的场景。每条尽量附来源章节与统计范围；没有样本写"未观察"）
- **D3 思维与价值观**：（世界观/论证方式/自我欺骗；附证据来源）
- **D4 情绪模式**：（基线/应激/压抑/触发事件；附场景证据）
- **D5 关系网络**：（对上级/同级/晚辈/亲友/敌人的称呼与距离；附称呼变化记录与场景）
- **D6 行为表达习惯**：（微动作/决策风格/沉默方式/改口习惯；附样本来源）
- **D7 变化、盲区与项目说明**：（与既往样本不同之处及触发事件；认知盲区；例外情境；
  需要人工判断的边界。作者明确确认的项目规则请标注"项目确认"及其适用范围）"""


def build_seven_dim_skeleton(names):
    skeleton = "\n\n".join(_dim_block(n) for n in names) if names else "（未扫描到角色；新增角色可复制下方模板逐个记录）\n"
    return f"""# 七维角色卡清单（本项目出声角色）

> 每个出声角色一张卡，七个维度：D1 身份与核心矛盾 / D2 语言观察与近期样本 / D3 思维与价值观 /
> D4 情绪模式 / D5 关系网络 / D6 行为表达习惯 / D7 变化、盲区与项目说明。
> 这是观察记录，记录角色在已写章节里是什么样、有什么变化；不是角色必须遵守的行为规定。
> 写作前可按需补充资料，写作后把新观察到的样本、变化和来源更新进来，没有观察到就留空或写"未观察"。

---

## 已识别角色（{len(names)} 个）

{skeleton}

---

## 空白模板（新增角色复制用）

```markdown
### <角色名>
- **D1 身份与核心矛盾**：
- **D2 语言观察与近期样本**：
- **D3 思维与价值观**：
- **D4 情绪模式**：
- **D5 关系网络**：
- **D6 行为表达习惯**：
- **D7 变化、盲区与项目说明**：
```
"""


def _voice_block(name):
    return f"""### {name}
- 近期语言样本：
- 常见表达倾向（如有）：
- 称呼与关系变化记录：
- 说话节奏的统计范围（如已统计；注明样本章节与条数）：
- 回避、改口或停顿的场景记录：
- 本次变化及其原因：
- 样本来源：
- 最近观察章节："""


def build_voice_baseline(names):
    body = "\n\n".join(_voice_block(n) for n in names) if names else "（尚无角色；新增角色时在上方按同一格式添加 `### 角色名` 小节即可）\n"
    return f"""# 语言观察与历史样本

> 记录角色在已观察章节中的表达、称呼、节奏和变化，供写作时参考和写后比较。
> 新章节与历史样本不同时，先记录差异、证据与可能原因，由作者决定保留、补充说明或复查；
> 差异本身不等于错误。统计范围之外的写法不做限制。

---

## 已识别角色（{len(names)} 个）

{body}
"""


# ---------------------------------------------------------------- 增量合并

def _existing_headings(text):
    """取已存在文件中的 `### <名>`（剔除围栏区与结构性名词）。"""
    clean = _strip_code_fences(text)
    out = []
    for raw in re.findall(r"^###\s+(.+?)\s*$", clean, re.M):
        n = normalize_char_name(raw)
        if n and not is_structural_name(n):
            out.append(n)
    return out


def merge_into_file(path, scanned_names, block_builder):
    """把缺失角色块安全并入技能生成文件（00/04）。返回新增角色数。

    非技能生成的自定义文件（无 `## 已识别角色` 标记）→ 尾部追加"增量更新"节，不重构结构。
    """
    if not os.path.exists(path):
        return -1
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()

    existing = _existing_headings(text)
    missing = []
    for n in scanned_names:
        nn = normalize_char_name(n)
        if not any(nn == e or nn in e or e in nn for e in existing):
            missing.append(n)
    if not missing:
        return 0

    new_blocks = "\n\n".join(block_builder(n) for n in missing)
    marker_pos = text.find("## 已识别角色")
    if marker_pos == -1:
        text = (text.rstrip() + f"\n\n---\n\n## 增量更新（{datetime.date.today().isoformat()}）\n\n"
                + new_blocks + "\n")
    else:
        footer = text.find("## 空白模板", marker_pos)
        if footer == -1:                     # 04 声线基线：无空白模板尾，追加到文件末
            text = text.rstrip() + "\n\n" + new_blocks + "\n"
        else:
            # 插到 footer 前最后一个分隔线之前（保持"正文 --- 空白模板"版式）
            sep = text.rfind("\n---\n", marker_pos, footer)
            ins = sep if sep != -1 else footer
            text = (text[:ins].rstrip() + "\n\n" + new_blocks + "\n\n" + text[ins:])
        new_total = len(existing) + len(missing)
        if new_total > 0:
            # 清掉"空模板"时留下的占位说明行（已有角色后不再需要）
            text = re.sub(r"^（未扫描到角色[^\n]*\n?|^（无识别角色[^\n]*\n?", "", text, flags=re.M)
        text = re.sub(r"^## 已识别角色（\d+ 个）",
                      lambda m: f"## 已识别角色（{new_total} 个）",
                      text, flags=re.M, count=1)

    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    return len(missing)


def prune_ghost_blocks(path):
    """移除 00/04 中结构性名词幽灵角色块（G1 现场清理），返回移除数。"""
    if not os.path.exists(path):
        return 0
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    out, removing, removed = [], False, 0
    for line in lines:
        m = re.match(r"^###\s+(.+?)\s*$", line)
        if m:
            removing = is_structural_name(m.group(1))
            if removing:
                removed += 1
                continue
        if removing:
            if re.match(r"^###\s+", line) or line.strip() in ("---", "```"):
                removing = False
            else:
                continue
        out.append(line)
    if removed:
        txt = "".join(out)
        cnt = len(_existing_headings(txt))
        txt = re.sub(r"^## 已识别角色（\d+ 个）",
                     lambda m: f"## 已识别角色（{cnt} 个）", txt, flags=re.M, count=1)
        with open(path, "w", encoding="utf-8") as f:
            f.write(txt)
    return removed


# ---------------------------------------------------------------- 状态探测 & 激活

def detect_state_sources(workdir):
    """探测可接入的追踪/状态源（供结构检查与审阅读取），仅报告不修改。"""
    chap = glob.glob(os.path.join(workdir, "**", "追踪", "逐章记录", "*.md"), recursive=True)
    pool = glob.glob(os.path.join(workdir, "**", "角色生态池", "*", "*", "01_persona_core.md"),
                     recursive=True)
    ns = glob.glob(os.path.join(workdir, ".novel_state", "*"), recursive=False)
    return {
        "追踪记录": len([p for p in chap if os.path.basename(p).startswith("第")]),
        "生态池角色": len(pool),
        ".novel_state": len([d for d in ns if os.path.isdir(d)]),
        "上下文": 1 if os.path.exists(os.path.join(workdir, "追踪", "上下文.md")) else 0,
    }


def ensure_activation_marker(workdir, version="2.6.2"):
    """登记技能激活标记（幂等）。落位优先级：manifest → .novel_state/<id>/ → 约束/.激活标记.md。"""
    now = datetime.datetime.now().isoformat(timespec="seconds")
    payload = {"dialogueSkill": {"version": version, "activatedAt": now, "active": True}}
    manifest = os.path.join(workdir, ".openwrite_manifest.json")
    if os.path.exists(manifest):
        try:
            with open(manifest, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = {}
        data.update(payload)
        with open(manifest, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return os.path.relpath(manifest, workdir)
    ns_dir = os.path.join(workdir, ".novel_state")
    ids = [d for d in os.listdir(ns_dir) if d] if os.path.isdir(ns_dir) else []
    if ids:
        p = os.path.join(ns_dir, sorted(ids)[0], "dialogue_skill.json")
        with open(p, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        return os.path.relpath(p, workdir)
    cdir = os.path.join(workdir, "约束")
    os.makedirs(cdir, exist_ok=True)
    p = os.path.join(cdir, ".激活标记.md")
    with open(p, "w", encoding="utf-8") as f:
        f.write(f"# 角色对话技能激活标记\n\n- 版本：{version}\n- 激活时间：{now}\n")
    return os.path.relpath(p, workdir)


# ---------------------------------------------------------------- 主流程

def main():
    ap = argparse.ArgumentParser(description="小说角色对话 · 约束文件夹初始化器 v2")
    ap.add_argument("workdir", nargs="?", default=os.getcwd(), help="小说工作目录")
    ap.add_argument("--mode", choices=["init", "update"], default="init",
                    help="init=缺文件即创建；update=强制增量合并（不覆盖手工内容）")
    ap.add_argument("--regen", action="store_true",
                    help="按扫描结果强制重建 00/04（会丢弃这两份文件的手工内容，仅模板空壳时使用）")
    ap.add_argument("--prune-ghosts", action="store_true",
                    help="清理 00/04 中结构性名词幽灵角色块（G1 现场清理）")
    ap.add_argument("--yes", action="store_true", help="跳过角色名单回读确认")
    ap.add_argument("--activate", action="store_true", help="登记技能激活标记")
    args = ap.parse_args()

    workdir = os.path.abspath(args.workdir)
    ref_dir = os.path.join(find_skill_root(), "references")
    cdir = os.path.join(workdir, "约束")

    if not os.path.isdir(ref_dir):
        print(f"[错误] 找不到技能 references 目录：{ref_dir}")
        sys.exit(1)
    if not os.path.isdir(workdir):
        print(f"[错误] 工作目录不存在：{workdir}")
        sys.exit(1)

    os.makedirs(cdir, exist_ok=True)

    # 1) 复制纯模板文件（目标已存在且不旧于母本 → 跳过，保护手工增补）
    copied = skipped = 0
    for src_name, dst_name in REFERENCE_MAP:
        src, dst = os.path.join(ref_dir, src_name), os.path.join(cdir, dst_name)
        if not os.path.exists(src):
            continue
        if os.path.exists(dst) and os.path.getmtime(dst) >= os.path.getmtime(src) - 1:
            skipped += 1
            continue
        shutil.copy2(src, dst)
        copied += 1

    # 2) 角色扫描（G1 修复后的两源采集）
    names = scan_characters(workdir)

    # 3) 名单回读确认（可定制兜底；终端不可用或 --yes 时跳过）
    if not args.yes and sys.stdin.isatty() and names:
        print("识别到的出声角色名单：")
        for i, n in enumerate(names, 1):
            print(f"  {i:>2}. {n}")
        ans = input("确认无误？直接回车继续；输入要删除的编号（逗号分隔）后回车：").strip()
        if ans:
            drop = {int(x) for x in re.split(r"[，,\s]+", ans) if x.strip().isdigit()}
            names = [n for i, n in enumerate(names, 1) if i not in drop]
            print(f"已按输入过滤，保留 {len(names)} 个。")

    # 4) 00 / 04 生成：regen=重建；否则文件缺失先建（骨架），已存在走增量合并（保护手工内容）
    p00, p04 = os.path.join(cdir, "00_七维角色卡清单.md"), os.path.join(cdir, "04_声线基线.md")
    if args.regen:
        with open(p00, "w", encoding="utf-8") as f:
            f.write(build_seven_dim_skeleton(names))
        with open(p04, "w", encoding="utf-8") as f:
            f.write(build_voice_baseline(names))
    else:
        if not os.path.exists(p00):
            with open(p00, "w", encoding="utf-8") as f:
                f.write(build_seven_dim_skeleton(names))
        if not os.path.exists(p04):
            with open(p04, "w", encoding="utf-8") as f:
                f.write(build_voice_baseline(names))
        merge_into_file(p00, names, _dim_block)
        merge_into_file(p04, names, _voice_block)

    if args.prune_ghosts:
        rm0, rm1 = prune_ghost_blocks(p00), prune_ghost_blocks(p04)
        print(f"  幽灵角色清理：00 移除 {rm0} 个 / 04 移除 {rm1} 个")

    # 5) 状态源报告 + 激活
    st = detect_state_sources(workdir)
    act_path = ensure_activation_marker(workdir) if args.activate else None

    print(f"约束文件夹已就绪：{cdir}")
    print(f"  参考文件：复制 {copied} 份 / 跳过（已有且较新）{skipped} 份")
    print(f"  识别角色：{len(names)} 个 -> {('、'.join(names)) if names else '无（已置空白模板）'}")
    print(f"  状态接入：追踪记录 {st['追踪记录']} · 生态池角色 {st['生态池角色']} · "
          f".novel_state {st['.novel_state']} 个 · 上下文 {'有' if st['上下文'] else '无'}")
    if act_path:
        print(f"  激活标记：{act_path}")
    print("  下一步（按需）：补充 00 角色观察 / 04 语言样本；需要审阅时对照 03 清单出差异报告；"
          "交付前可选跑 novel-audit A1。")


if __name__ == "__main__":
    main()
