#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小说角色对话 · references 母本 ↔ 约束副本 同源同步器（设计方案 I3 / 修复 G4）

问题背景：references/ 为模板母本，`约束/` 为项目副本；项目副本允许本地增补章节
（如龙族 05 增补"十、与七维卡对接"），若只从母本单向复制会丢本地增补，若只留
本地又会与母本漂移。本脚本提供两个方向的对齐：

  pull   <workdir>            母本 → 约束：01/02/03/05 等纯模板文件下拉同步。
                               目标较新（有本地增补）则跳过并提示（先用 push 回并母本）。
  push   <workdir> [--file X] 约束 → 母本：把项目副本中"母本没有的 ## 章节"按序回并
                               进 references 母本（幂等：同标题同内容不重复追加）。

用法：
  python scripts/sync_constraints.py <工作目录> pull
  python scripts/sync_constraints.py <工作目录> push --file 05_网文对话语料.md
  python scripts/sync_constraints.py <工作目录> push --all
"""

import os
import re
import sys
import shutil
import argparse

# 纯模板文件（可下拉覆盖的）；00/04 为项目生成文件，永不参与同步
PULLABLE = ["01_对话风格规则.md", "02_创作规范集成.md", "03_角色一致性检查清单.md",
            "05_网文对话语料.md"]
# 母本文件名
MOTHER_NAMES = {
    "01_对话风格规则.md": "对话风格规则.md",
    "02_创作规范集成.md": "创作规范集成.md",
    "03_角色一致性检查清单.md": "角色一致性检查清单.md",
    "05_网文对话语料.md": "网文角色对话指导性文件.md",
}


def find_skill_root():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(here)


def split_sections(text):
    """按 `## ` 标题把文本切成 [(heading, body), ...]，保留文件头（首个 ## 之前）另行返回。"""
    lines = text.splitlines(keepends=True)
    head = []
    sections = []
    cur_heading = None
    cur_body = []
    for ln in lines:
        if ln.startswith("## "):
            if cur_heading is not None:
                sections.append((cur_heading, "".join(cur_body)))
            cur_heading = ln.strip()
            cur_body = []
        else:
            if cur_heading is None:
                head.append(ln)
            else:
                cur_body.append(ln)
    if cur_heading is not None:
        sections.append((cur_heading, "".join(cur_body)))
    return "".join(head), sections


def cmd_pull(workdir, constraint_dir, ref_dir):
    done, skipped = [], []
    for dst_name in PULLABLE:
        src = os.path.join(ref_dir, MOTHER_NAMES[dst_name])
        dst = os.path.join(constraint_dir, dst_name)
        if not os.path.exists(src):
            skipped.append(f"{dst_name}（母本缺失）")
            continue
        if os.path.exists(dst) and os.path.getmtime(dst) >= os.path.getmtime(src) - 1:
            skipped.append(f"{dst_name}（副本较新，疑似有本地增补，先 push 回并再 pull）")
            continue
        shutil.copy2(src, dst)
        done.append(dst_name)
    print(f"pull 完成：更新 {len(done)} 份 -> {('、'.join(done)) if done else '无'}")
    if skipped:
        print(f"跳过 {len(skipped)} 份 -> {('、'.join(skipped))}")


def cmd_push(workdir, constraint_dir, ref_dir, file_filter=None, push_all=False):
    targets = PULLABLE if push_all else ([file_filter] if file_filter else ["05_网文对话语料.md"])
    for dst_name in targets:
        if dst_name not in MOTHER_NAMES:
            continue
        src = os.path.join(constraint_dir, dst_name)
        mother = os.path.join(ref_dir, MOTHER_NAMES[dst_name])
        if not os.path.exists(src):
            print(f"push 跳过：约束副本不存在 {dst_name}")
            continue
        if not os.path.exists(mother):
            print(f"push 跳过：母本不存在 {MOTHER_NAMES[dst_name]}（首次可先 pull 建立）")
            continue
        with open(src, "r", encoding="utf-8") as f:
            s_head, s_sections = split_sections(f.read())
        with open(mother, "r", encoding="utf-8") as f:
            m_head, m_sections = split_sections(f.read())
        existing_heads = {h for h, _ in m_sections}
        existing_sig = {(h, re.sub(r"\s+", "", b)) for h, b in m_sections}
        added = []
        for h, b in s_sections:
            if h in existing_heads:
                continue
            sig = (h, re.sub(r"\s+", "", b))
            if sig in existing_sig:
                continue
            added.append((h, b))
        if not added:
            print(f"push 无新增：{dst_name} 与母本一致或已回并")
            continue
        tail = "\n".join(f"{h}\n{b}".rstrip() + "\n" for h, b in added)
        with open(mother, "a", encoding="utf-8") as f:
            f.write("\n" + tail)
        print(f"push 回并 {len(added)} 节 -> {MOTHER_NAMES[dst_name]}：")
        for h, _ in added:
            print(f"  + {h}")


def main():
    ap = argparse.ArgumentParser(description="references 母本 ↔ 约束副本 同源同步器")
    ap.add_argument("workdir", nargs="?", default=os.getcwd())
    ap.add_argument("cmd", choices=["pull", "push"])
    ap.add_argument("--file", default=None, help="push 指定文件（约束侧名，如 05_网文对话语料.md）")
    ap.add_argument("--all", action="store_true", help="push 全部可回并文件")
    args = ap.parse_args()

    workdir = os.path.abspath(args.workdir)
    ref_dir = os.path.join(find_skill_root(), "references")
    cdir = os.path.join(workdir, "约束")
    if not os.path.isdir(ref_dir):
        print(f"[错误] 找不到 references：{ref_dir}")
        sys.exit(1)
    if not os.path.isdir(cdir):
        print(f"[错误] 找不到约束文件夹：{cdir}（先跑 init_constraints.py）")
        sys.exit(1)

    if args.cmd == "pull":
        cmd_pull(workdir, cdir, ref_dir)
    else:
        cmd_push(workdir, cdir, ref_dir, args.file, args.all)


if __name__ == "__main__":
    main()
