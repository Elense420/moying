#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小说角色对话 · 表达样本灌入器（设计方案升级一 / G5+G9）

把"人物库.md / 角色生态池 / 约束 00 七维卡"三源中**已由人工确认或从真实样本提取**的
语言字段灌入 `.novel_state/<书名>/characters.json`（或项目根 `约束/characters.json`），
供 novel-audit 的 d3.json 声线检测管道使用
（speech_signature_hits / catchphrase_stats / voice_protection / speaker_mbti_mismatch 四字段）。

原则：只搬运"写出来的值"。空白字段、模板占位、原型默认值都不会被写入，
因此新项目在缺少真实样本时不会凭空获得口头语、句长或句式设定。

用法：
  python scripts/seed_speech_signature.py <工作目录> [--book 书名] [--dry-run]

数据源优先级（高→低，冲突以高优先）：
  1. 人物库.md（**/人物库.md / **/小说资料/人物库.md）——作者裁定的表达字段与称呼锚点
  2. 角色生态池 9+1 卡（01_persona_core.md 表达样本 / 05_behavior.md 行为习惯）
  3. 约束 00_七维角色卡清单.md（D2 语言观察与近期样本｜旧标题 D2 声线特征、D4 触发事件、D5 称呼）
"""

import os
import re
import sys
import glob
import json
import argparse

# 从 Markdown 中抽取字段的键名映射（数据源文本里可能出现的键名 → JSON 字段）
FIELD_KEYS = {
    "口头禅": ["口头禅", "口癖", "高频词", "常用语"],
    "禁用词": ["禁用词", "禁说", "不会说的话"],
    "称呼习惯": ["称呼锚点", "称呼习惯", "称呼"],
    "句长偏好": ["句长", "平均句长"],
    "互动梗": ["互动梗", "互动细节", "标志性动作"],
    "触发器": ["触发器", "破功", "失态"],
}


def find_skill_root():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(here)


def norm_name(n):
    n = n.strip().strip("《》").strip()
    n = re.sub(r"^\d+[_\s、.．:：-]*", "", n)
    n = re.sub(r"[（(].*?[）)]", "", n)      # 去括号注（"苏九（待定名，可修改）"→"苏九"）
    return re.sub(r"\s+", "", n)


# ---------------------------------------------------------------- 源 1：人物库.md

def parse_renwuku(path):
    """从人物库.md 抽取每角色的 口头禅/称呼锚点/互动梗。

    支持两种形态：
      a. ### 角色名 分节，节内 `- 口头禅：xxx` 或 `口头禅：xxx`；
      b. 表格/段落混排，按 `**角色名**` 或 `## 角色名` 切块。
    返回 {角色名: {字段: 值}}。
    """
    out = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    except Exception:
        return out
    clean = re.sub(r"```.*?```", "", text, flags=re.S)
    # 按 ### 或 ## 角色名 切块
    blocks = re.split(r"^(#{2,3})\s+(.+?)\s*$", clean, flags=re.M)
    # blocks = [前言, 级别, 名, 体, 级别, 名, 体, ...]
    for i in range(1, len(blocks) - 2, 3):
        name = norm_name(blocks[i + 1])
        body = blocks[i + 2]
        if not name or len(name) > 14:
            continue
        fields = {}
        for json_key, candidates in FIELD_KEYS.items():
            for cand in candidates:
                # 匹配 `- **口头禅**：值` 或 `- 口头禅：值` 或 `口头禅：值`（兼容加粗）
                m = re.search(
                    rf"[*\-]?\s*\*?\*?{cand}\*?\*?\s*[：:]\s*(.+?)(?:\n|$)", body)
                if m:
                    val = m.group(1).strip().strip("*").strip()
                    if val and val not in ("（空）", "无", "—", "-"):
                        fields[json_key] = val
                    break
        if fields:
            out[name] = fields
    return out


# ---------------------------------------------------------------- 源 2：角色生态池

def parse_eco_pool(workdir):
    """从角色生态池 9+1 卡抽取口头禅（01_persona_core）与微习惯（05_behavior）。"""
    out = {}
    for pool in glob.glob(os.path.join(workdir, "**", "角色生态池"), recursive=True):
        for novel_dir in os.listdir(pool):
            if novel_dir.startswith("."):
                continue
            novel_path = os.path.join(pool, novel_dir)
            if not os.path.isdir(novel_path):
                continue
            for char_dir in os.listdir(novel_path):
                if char_dir.startswith("."):
                    continue
                char_path = os.path.join(novel_path, char_dir)
                if not os.path.isdir(char_path):
                    continue
                name = norm_name(char_dir)
                fields = {}
                # 01_persona_core.md 口头禅
                p1 = os.path.join(char_path, "01_persona_core.md")
                if os.path.exists(p1):
                    with open(p1, "r", encoding="utf-8") as f:
                        t = f.read()
                    m = re.search(r"口头禅[：:]\s*(.+?)(?:\n|$)", t)
                    if m:
                        fields["口头禅"] = m.group(1).strip()
                # 05_behavior.md 微习惯/决策风格 → 回避方式
                p5 = os.path.join(char_path, "05_behavior.md")
                if os.path.exists(p5):
                    with open(p5, "r", encoding="utf-8") as f:
                        t = f.read()
                    m = re.search(r"(?:微习惯|沉默方式|回避方式)[：:]\s*(.+?)(?:\n|$)", t)
                    if m:
                        fields["回避方式"] = m.group(1).strip()
                if fields:
                    out[name] = fields
    return out


# ---------------------------------------------------------------- 源 3：约束 00 七维卡

def parse_qiweika(path):
    """从约束 00_七维角色卡清单.md 抽取 D2/D4/D5 字段。

    兼容两代标题：
      - v2.5.2+：`D2 语言观察与近期样本`（观察记录型）
      - 旧项目：`D2 声线特征`（规范型）
    解析规则：只提取正文里**实际写出的值**；空白项（只有字段名没有内容）不产出字段，
    因此新项目不会因模板存在而被自动写入口头语/句长/句式等设定。
    """
    out = {}
    if not os.path.exists(path):
        return out
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    clean = re.sub(r"```.*?```", "", text, flags=re.S)
    blocks = re.split(r"^###\s+(.+?)\s*$", clean, flags=re.M)
    for i in range(1, len(blocks) - 1, 2):
        name = norm_name(blocks[i])
        body = blocks[i + 1]
        if not name or name.startswith("<"):
            continue
        fields = {}
        # D2（新旧标题）→ 口癖/句长/称呼
        m = re.search(r"\*\*D2 (?:语言观察与近期样本|声线特征)\*\*[：:]\s*(.+?)(?=\n- |\n\n|$)",
                      body, re.S)
        if m:
            d2 = m.group(1)
            for key, pat in (("口头禅", r"口癖[/＝=]([^；;，,\n]+)"),
                             ("句长偏好", r"句长[/＝=]?([^；;，,\n]+)"),
                             ("称呼习惯", r"称呼[/＝=]([^；;，,\n]+)")):
                mm = re.search(pat, d2)
                if mm:
                    fields[key] = mm.group(1).strip()
        # D4 触发事件（兼容旧标题"触发器"）
        m = re.search(r"\*\*D4 情绪模式\*\*[：:].*?(?:触发事件|触发器)[/＝=]([^；;）)\n]+)", body)
        if m:
            fields["触发器"] = m.group(1).strip()
        # D5 称呼与距离（仅当 D2 未给出称呼时回退）
        m = re.search(r"\*\*D5 关系网络\*\*[：:]\s*(.+?)(?=\n- |\n\n|$)", body, re.S)
        if m and "称呼习惯" not in fields:
            val = m.group(1).strip()
            if val and not val.startswith("（"):
                fields["称呼习惯"] = val
        if fields:
            out[name] = fields
    return out


# ---------------------------------------------------------------- 合并与灌入

def merge_fields(sources):
    """三源合并：人物库 > 生态池 > 七维卡（高优先覆盖低优先）。"""
    merged = {}
    for src in sources:  # 按优先级从低到高传入
        for name, fields in src.items():
            merged.setdefault(name, {}).update(fields)
    return merged


def to_speech_signature(fields):
    """字段集 → characters.json 的 speech_signature 结构。"""
    sig = {
        "口头禅": _to_list(fields.get("口头禅")),
        "禁用词": _to_list(fields.get("禁用词")),
        "称呼习惯": _to_dict(fields.get("称呼习惯")),
        "句长偏好": fields.get("句长偏好"),
        "声线句式": _to_list(fields.get("声线句式")),
        "回避方式": fields.get("回避方式"),
    }
    trigger = {}
    if fields.get("触发器"):
        trigger["失态条件"] = fields["触发器"]
    if fields.get("互动梗"):
        trigger["互动梗"] = fields["互动梗"]
    return sig, trigger


def _to_list(v):
    if not v:
        return []
    if isinstance(v, list):
        return v
    s = str(v)
    # 保护引号内内容不被顿号/逗号误切（"修炼是不可能修炼的，这辈子都不可能修炼的。""今天你打卡了吗？"）
    quoted = re.findall(r'"([^"]+)"|"([^"]+)"|「([^」]+)」|『([^』]+)』', s)
    if quoted:
        return [next(g for g in tup if g) for tup in quoted]
    return [x.strip() for x in re.split(r"[/、，,；;]", s) if x.strip()]


def _to_dict(v):
    if not v:
        return {}
    if isinstance(v, dict):
        return v
    out = {}
    for pair in re.split(r"[；;]", str(v)):
        if "＝" in pair or "=" in pair or "：" in pair or ":" in pair:
            parts = re.split(r"[＝=：:]", pair, maxsplit=1)
            if len(parts) == 2:
                k, val = parts
                out[k.strip()] = val.strip()
            else:
                out[pair.strip()] = pair.strip()   # 无键值对时以自身为键
    return out


def load_characters_json(path):
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"_meta": {"characters": {}}, "characters": {}}


def main():
    ap = argparse.ArgumentParser(description="表达样本灌入器")
    ap.add_argument("workdir", nargs="?", default=os.getcwd())
    ap.add_argument("--book", default=None, help="书名（用于定位 .novel_state/<书名>/）")
    ap.add_argument("--dry-run", action="store_true", help="只打印 diff 不落盘")
    args = ap.parse_args()

    workdir = os.path.abspath(args.workdir)

    # 定位 characters.json
    if args.book:
        cj = os.path.join(workdir, ".novel_state", args.book, "characters.json")
    else:
        # 探测 .novel_state 下第一个子目录
        ns = os.path.join(workdir, ".novel_state")
        subs = [d for d in os.listdir(ns) if os.path.isdir(os.path.join(ns, d))] if os.path.isdir(ns) else []
        cj = os.path.join(ns, subs[0], "characters.json") if subs else os.path.join(workdir, "约束", "characters.json")
    os.makedirs(os.path.dirname(cj), exist_ok=True)

    # 三源采集
    src_renwuku = {}
    for p in glob.glob(os.path.join(workdir, "**", "人物库.md"), recursive=True) + \
             glob.glob(os.path.join(workdir, "**", "小说资料", "人物库.md"), recursive=True):
        src_renwuku.update(parse_renwuku(p))
    src_pool = parse_eco_pool(workdir)
    src_qwk = parse_qiweika(os.path.join(workdir, "约束", "00_七维角色卡清单.md"))

    # 合并（七维卡 低 → 生态池 → 人物库 高）
    merged = merge_fields([src_qwk, src_pool, src_renwuku])
    if not merged:
        print("[提示] 三源均未采到声线字段（人物库/生态池/七维卡），未灌入。")
        return

    data = load_characters_json(cj)
    chars = data.setdefault("characters", {})
    added = updated = conflict = 0
    for name, fields in merged.items():
        sig, trigger = to_speech_signature(fields)
        if name in chars:
            # 已有角色：本次新解析出的值覆盖同名字段（修复坏数据/补缺口）；
            # 人工填的其它字段（禁用词/句长偏好等）不动。
            existing = chars[name].setdefault("speech_signature", {})
            for k, v in sig.items():
                if v:
                    if existing.get(k) != v:
                        existing[k] = v
                        updated += 1
            if trigger:
                ts = chars[name].setdefault("trigger_state", {})
                for k, v in trigger.items():
                    if k not in ts:
                        ts[k] = v
                        updated += 1
        else:
            chars[name] = {"speech_signature": sig, "trigger_state": trigger}
            added += 1

    print(f"表达样本灌入：{cj}")
    print(f"  数据源：人物库 {len(src_renwuku)} · 生态池 {len(src_pool)} · 七维卡 {len(src_qwk)} 角色")
    print(f"  新增角色 {added} / 补字段 {updated} / 冲突保留人工值 {conflict}")
    for name in merged:
        print(f"    - {name}: {list(merged[name].keys())}")
    if args.dry_run:
        print("  [dry-run] 未落盘")
    else:
        with open(cj, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print("  已写回。下一步：novel-audit A1 复跑，验证 d3.json speech_signature_hits 激活"
              "（仅当上方提取到真实样本字段时才有效）。")


if __name__ == "__main__":
    main()
