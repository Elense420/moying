#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小说角色对话 · 差异化候选生成引擎 v2.5.0

引擎是候选生成器与统计工具：产出"选项桶 + 话轮抽样参数"，不产出成文，
也不规定角色应当如何说话——候选可整体采纳、部分改写或全部不用。

差异化三源：属性（性格×谱系×身份×年龄）× 历史行为库 × 随机种子。

性格模型（双轨）：
  底层=大五连续空间 O/C/E/A/N 每维 [0,1]（覆盖较广的性格分布，任意两角色可算差异与对撞）
  表层=原型标签（八型内置 + 开放注册；写作抓手）
三层稳定性（引擎默认模型，项目可覆盖）：根性格（默认长期稳定，改写由作者在七维卡登记）/
  表层（默认弹性 ±0.2 摆动 + 回拉）/ 状态（瞬时）

用法见 references/工作流-差异化生成引擎.md；selftest 跑内置边界用例回归。
"""

import os
import re
import sys
import json
import random
import argparse
import datetime

BIG5_DIMS = ("O", "C", "E", "A", "N")
SURFACE_BAND = 0.2
PULLBACK = 0.03
DEV_STEP = 0.05
ROOT_REWRITE_MAX = 2
CLASH_THRESHOLD = 0.6
OUTLIER_SIGMA = 3.0

FALLBACK_BIG5 = {"O": 0.6, "C": 0.6, "E": 0.4, "A": 0.7, "N": 0.5}
DEFAULT_ARCHETYPE = "温柔"

ARCHETYPES = {
    "社牛": {"big5": {"O": 0.7, "C": 0.4, "E": 0.9, "A": 0.8, "N": 0.3},
             "句长": (10, 22), "语气词": (2, 4), "话轮": (3, 6), "延迟": "快",
             "主导": (0.7, 0.9), "通道": {"话语": 0.6, "动作": 0.2, "物件": 0.1, "环境": 0.1},
             "动作库": ["拍肩", "揽过来", "递东西", "起外号"],
             "口癖池": ["哟", "好家伙", "走起", "我跟你讲"],
             "劣化": "没心没肺的热闹"},
    "社恐": {"big5": {"O": 0.5, "C": 0.6, "E": 0.2, "A": 0.7, "N": 0.8},
             "句长": (3, 12), "语气词": (0, 1), "话轮": (1, 2), "延迟": "慢",
             "主导": (0.1, 0.3), "通道": {"动作": 0.5, "环境": 0.3, "物件": 0.1, "话语": 0.1},
             "动作库": ["缩回去", "往后退半步", "探头又缩回", "假装看别处"],
             "口癖池": ["那个", "就是", "嗯"],
             "劣化": "哑巴、只会嗯"},
    "毒舌": {"big5": {"O": 0.6, "C": 0.5, "E": 0.6, "A": 0.4, "N": 0.5},
             "句长": (4, 16), "语气词": (1, 2), "话轮": (1, 3), "延迟": "快",
             "主导": (0.4, 0.7), "通道": {"话语": 0.5, "动作": 0.3, "物件": 0.1, "环境": 0.1},
             "动作库": ["丢过去", "别过脸", "递完就走", "哼一声"],
             "口癖池": ["哟", "您这", "行行行", "得了吧"],
             "劣化": "无差别辱骂"},
    "憨直": {"big5": {"O": 0.3, "C": 0.7, "E": 0.5, "A": 0.8, "N": 0.4},
             "句长": (8, 18), "语气词": (0, 1), "话轮": (2, 4), "延迟": "中",
             "主导": (0.3, 0.5), "通道": {"动作": 0.5, "话语": 0.3, "物件": 0.1, "环境": 0.1},
             "动作库": ["挠头", "直愣愣看过去", "把话重说一遍", "掰手指头"],
             "口癖池": ["俺", "那啥", "俺寻思"],
             "劣化": "蠢、工具人"},
    "通透": {"big5": {"O": 0.8, "C": 0.6, "E": 0.4, "A": 0.8, "N": 0.2},
             "句长": (12, 24), "语气词": (0, 0), "话轮": (1, 2), "延迟": "慢",
             "主导": (0.3, 0.5), "通道": {"环境": 0.4, "动作": 0.3, "物件": 0.2, "话语": 0.1},
             "动作库": ["放下手里的事", "倒茶", "停一停再开口", "指个方向"],
             "口癖池": ["来", "坐", "喝茶"],
             "劣化": "世外高人腔"},
    "阴沉": {"big5": {"O": 0.6, "C": 0.6, "E": 0.3, "A": 0.3, "N": 0.7},
             "句长": (4, 10), "语气词": (0, 0), "话轮": (1, 2), "延迟": "不答",
             "主导": (0.2, 0.4), "通道": {"动作": 0.6, "环境": 0.2, "物件": 0.1, "话语": 0.1},
             "动作库": ["盯住对方", "按住东西", "起身离开", "把门关上"],
             "口癖池": ["嗯", "知道了", "滚"],
             "劣化": "沉默当万能情绪"},
    "傲娇": {"big5": {"O": 0.5, "C": 0.6, "E": 0.5, "A": 0.5, "N": 0.7},
             "句长": (5, 14), "语气词": (1, 2), "话轮": (1, 3), "延迟": "先快后慢",
             "主导": (0.4, 0.6), "通道": {"动作": 0.5, "物件": 0.3, "话语": 0.2, "环境": 0.0},
             "动作库": ["扭头", "找借口", "把东西塞过去", "小声补一句"],
             "口癖池": ["才没有", "谁、谁要你管", "刚好路过"],
             "劣化": "纯粹讨嫌"},
    "温柔": {"big5": {"O": 0.6, "C": 0.7, "E": 0.4, "A": 0.9, "N": 0.3},
             "句长": (8, 16), "语气词": (0, 1), "话轮": (2, 3), "延迟": "中",
             "主导": (0.3, 0.5), "通道": {"物件": 0.4, "动作": 0.3, "话语": 0.2, "环境": 0.1},
             "动作库": ["把东西放好", "递过去", "收好对方的东西", "轻轻带上门"],
             "口癖池": ["没事", "慢慢来", "我来吧"],
             "劣化": "没脾气的圣母"},
}


# ---------------------------------------------------------------- 词汇参数层（v2.5.1）

def vocab_path():
    return os.path.join(find_skill_root(), "references", "性格词汇参数库.json")
GRADE_RANGES = {"高": (0.70, 0.85), "中高": (0.60, 0.70), "中": (0.45, 0.55),
                "中低": (0.30, 0.40), "低": (0.15, 0.30)}
IMG_RE = re.compile(r"外向(?P<E>高|中高|中低|中|低)、宜人(?P<A>高|中高|中低|中|低)、"
                    r"尽责(?P<C>高|中高|中低|中|低)、情绪稳(?P<S>高|中高|中低|中|低)、"
                    r"开放(?P<O>高|中高|中低|中|低)")


def load_vocab():
    vp = vocab_path()
    if not os.path.exists(vp):
        return {}
    with open(vp, "r", encoding="utf-8") as f:
        return {w["词汇"]: w for w in json.load(f).get("words", [])}


def grade_to_range(grade):
    """文档五档 → 坐标区间；熵关取中点。"""
    return GRADE_RANGES.get(grade, GRADE_RANGES["中"])


def img_to_coords(img_str, rng=None):
    """大五画像字符串 → OCEAN 坐标区间中点（情绪稳 → N 反向）。"""
    m = IMG_RE.match(img_str)
    if not m:
        return None
    mid = lambda g: sum(grade_to_range(g)) / 2
    return {
        "O": mid(m.group("O")), "C": mid(m.group("C")), "E": mid(m.group("E")),
        "A": mid(m.group("A")), "N": 1 - mid(m.group("S")),   # 情绪稳高 = N 低
    }


def synth_coords(main_word, aux_words):
    """词汇合成：主词 0.6 + 辅词 0.25/0.15 加权合成画像坐标。"""
    vocab = load_vocab()
    weights = [0.6, 0.25, 0.15]
    acc = {d: 0.0 for d in BIG5_DIMS}
    used = 0
    for word, w in [(main_word, weights[0])] + [(a, weights[i + 1]) for i, a in enumerate(aux_words or [])]:
        v = vocab.get(word)
        if not v:
            continue
        c = img_to_coords(v["画像"])
        if not c:
            continue
        for d in BIG5_DIMS:
            acc[d] += c[d] * w
        used += w
    if used <= 0:
        return None
    return {d: clamp01(acc[d] / used) for d in BIG5_DIMS}


def vocab_risk(word):
    """风险列 → 劣化边界语料（分号后部分）。"""
    v = load_vocab().get(word)
    if not v:
        return []
    risk = v.get("优势与风险", "")
    parts = [p.strip() for p in risk.split("；") if p.strip()]
    return parts[1:] if len(parts) > 1 else parts


def check_label(text, vocab_names):
    """B12 贴死标签检测：正文出现"他是X/是个X的人"式性格标签句（advisory）。"""
    hits = []
    for w in vocab_names:
        if re.search(rf"(?:他|她|这人|那人)[^。\n]{{0,8}}(?:是个|就是个|像个|太){w}(?:的人)?", text):


            hits.append(w)
    return sorted(set(hits))
STAGE_WEIGHTS = {
    "首章":   {"attr": 0.60, "hist": 0.15, "seed": 0.25},
    "成长期": {"attr": 0.40, "hist": 0.40, "seed": 0.20},
    "成熟期": {"attr": 0.25, "hist": 0.55, "seed": 0.20},
}

DELAY_ORDER = {"快": 0, "中": 1, "慢": 2, "不答": 3}


def clamp01(x):
    return round(max(0.0, min(1.0, x)), 2)


def clamp_band(root, surface):
    """表层钳制到根坐标 ±SURFACE_BAND。返回 (钳后, 触顶维度列表)。"""
    out, touch = {}, []
    for d in BIG5_DIMS:
        lo, hi = clamp01(root[d] - SURFACE_BAND), clamp01(root[d] + SURFACE_BAND)
        out[d] = clamp01(surface[d])
        if surface[d] >= hi - 1e-9 and root[d] < hi:
            touch.append(d)
    return out, touch


class RNG:
    """可复现种子 + 可选真随机混入。"""

    def __init__(self, base, entropy=False):
        self.entropy = entropy
        self._r = random.Random(base)

    def random(self):
        if self.entropy:
            return (self._r.random() + random.random()) / 2.0
        return self._r.random()

    def uniform(self, a, b):
        return a + (b - a) * self.random()

    def choice(self, seq):
        return seq[int(self.random() * len(seq)) % len(seq)]

    def weighted(self, items, weights):
        """items: [(item, w)] 带权抽样。"""
        total = sum(w for _, w in items)
        r = self.random() * total
        acc = 0.0
        for it, w in items:
            acc += w
            if r <= acc:
                return it
        return items[-1][0]


def find_skill_root():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# ---------------------------------------------------------------- 特征向量

def engine_dir(workdir, book):
    return os.path.join(workdir, ".novel_state", book, "dialogue_engine")


def load_char(workdir, book, name):
    p = os.path.join(engine_dir(workdir, book), f"{name}.json")
    if not os.path.exists(p):
        return None
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def save_char(workdir, book, char):
    d = engine_dir(workdir, book)
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, f"{char['name']}.json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(char, f, ensure_ascii=False, indent=2)
    return p


def new_char(name, proto=None, big5=None, vocab_main=None, vocab_aux=None):
    """建卡：属性缺失回退默认；自定义坐标跳过原型校验。"""
    proto = proto or DEFAULT_ARCHETYPE
    arch = ARCHETYPES.get(proto)
    if arch is None:
        # 未注册原型：按未知处理，回退温柔 + 标记
        arch = ARCHETYPES[DEFAULT_ARCHETYPE]
    if big5:
        root = {d: clamp01(float(big5[d])) for d in BIG5_DIMS}
    elif vocab_main:
        root = synth_coords(vocab_main, vocab_aux)
        if root is None:
            root = dict(arch["big5"])          # 词汇库缺失回退原型
    else:
        root = dict(arch["big5"])
    root_fallback = big5 is None and vocab_main is None and arch is ARCHETYPES[DEFAULT_ARCHETYPE]
    proto_main = (vocab_main if (vocab_main in ARCHETYPES) else proto)
    return {
        "name": name,
        "F_attr": {
            "性格": {"根": root, "表层": dict(root),
                     "原型": {"主": proto_main, "副": None, "比例": [0.7, 0.3]},
                     "根声明": None,
                     "fallback": root_fallback,
                     "未注册": not (proto in ARCHETYPES),
             "词汇": {"主": vocab_main, "辅": vocab_aux or []}},
            "谱系": "默认", "身份": "", "年龄": None,
            "语种混杂": "无",
        },
        "F_hist": {
            "句长": {"样本": [], "均值": None, "方差": None},
            "口癖频次": {}, "代偿动作库": {}, "情绪通道": {"动作": 0, "物件": 0, "环境": 0, "话语": 0},
            "事件表": [],
            "根改写次数": 0,
        },
        "F_seed": {"base": random.Random(name).randint(1, 999999), "entropy": True},
        "updated": datetime.date.today().isoformat(),
    }


def stage_of(char):
    ev = len(char["F_hist"]["事件表"])
    n = len(char["F_hist"]["句长"]["样本"])
    if ev >= 15 or n >= 150:
        return "成熟期"
    if ev >= 5 or n >= 50:
        return "成长期"
    return "首章"


def hist_stats(char):
    samples = char["F_hist"]["句长"]["样本"]
    if not samples:
        return None, None
    mean = sum(samples) / len(samples)
    var = sum((x - mean) ** 2 for x in samples) / len(samples)
    return round(mean, 1), round(var ** 0.5, 1)


# ---------------------------------------------------------------- 对撞

def big5_of(char):
    return char["F_attr"]["性格"]["表层"] or char["F_attr"]["性格"]["根"]


def clash(a, b):
    ga, gb = big5_of(a), big5_of(b)
    return round(0.4 * abs(ga["E"] - gb["E"]) + 0.2 * abs(ga["A"] - gb["A"])
                 + 0.2 * abs(ga["O"] - gb["O"]) + 0.1 * abs(ga["N"] - gb["N"])
                 + 0.1 * abs(ga["C"] - gb["C"]), 2)


def clash_direction(a, b):
    """返回化学反应方向标签（用于生成层叠加提示）。"""
    ga, gb = big5_of(a), big5_of(b)
    if ga["A"] < 0.4 and gb["A"] < 0.4:
        return "双低宜人-边界线对白"
    if ga["E"] - gb["E"] >= 0.4:
        return f"{a['name']}进攻-{b['name']}后退"
    if gb["E"] - ga["E"] >= 0.4:
        return f"{b['name']}进攻-{a['name']}后退"
    if abs(ga["O"] - gb["O"]) >= 0.3:
        return "认知差-鸡同鸭讲"
    return "中性"


# ---------------------------------------------------------------- 生成

def arch_params(char):
    proto = char["F_attr"]["性格"]["原型"]["主"]
    arch = ARCHETYPES.get(proto, ARCHETYPES[DEFAULT_ARCHETYPE])
    return arch


def build_buckets(char, scene, rng, mood="基线"):
    """三桶 + 话轮三参数。"""
    arch = arch_params(char)
    hist = char["F_hist"]
    age = char["F_attr"].get("年龄")
    age_k = 0.8 if age and age < 16 else (1.1 if age and age > 50 else 1.0)

    # 句长：性格区间 ∩ 历史均值±1σ，再乘应激/年龄
    lo, hi = arch["句长"]
    mean, sigma = hist_stats(char)
    if mean is not None:
        eff_sigma = sigma if sigma and sigma >= 1.5 else 3
        lo = max(lo, int(mean - eff_sigma))
        hi = min(hi, int(mean + eff_sigma))
    if mood == "应激":
        lo, hi = int(lo * 0.6), int(hi * 0.6)
    lo, hi = int(lo * age_k), max(lo, int(hi * age_k))

    # 三桶（每桶 = A 层 + H 层 + R 层 候选，权重在 gen 中分配）
    # 标签统一标注「参考/候选」：数值是抽样参数与历史统计，不是对写作的硬性限制
    if mean is not None:
        hist_note = f"（参考历史样本均值 {mean:.1f}，已取 ±1σ 交集）"
    else:
        hist_note = "（原型默认范围，暂无历史样本）"
    content_bucket = [
        (f"节奏参考：句长 {lo}-{hi} 字{hist_note}", 1.0),
        (f"常用表达样本参考（原型默认，可选）{arch['口癖池']}", 0.6),
    ]
    # 词汇参数层：典型表现短语进内容桶（v2.5.1）
    for vw in ([char["F_attr"]["性格"].get("词汇", {}).get("主")] +
               char["F_attr"]["性格"].get("词汇", {}).get("辅", [])):
        v = load_vocab().get(vw)
        if v and v.get("典型表现"):
            content_bucket.append((f"表现倾向（{vw}）：{v['典型表现'][:18]}", 0.9))
    act_hist = hist["代偿动作库"]
    pre_bucket = [(a, 1.0) for a in arch["动作库"]]
    for a, c in sorted(act_hist.items(), key=lambda x: -x[1])[:2]:
        pre_bucket.append((a, 0.8 * min(c, 3)))
    pre_bucket.append((f"库外扰动：{rng.choice(['整理手边东西', '把窗开了一条缝', '站到光线外'])}", 0.4))

    channels = arch["通道"]
    ch_hist = hist["情绪通道"]
    body_bucket = [(k, v * (1 + min(ch_hist.get(k, 0), 3) * 0.3)) for k, v in channels.items()]
    body_bucket.append(("过程化展开建议（起点→蔓延→出口；通用感官套话可考虑替换）", 0.5))

    turn = {
        "话轮长度": (max(1, arch["话轮"][0]), arch["话轮"][1]),
        "回应延迟": arch["延迟"],
        "话题主导度": arch["主导"],
    }
    return {"content": content_bucket, "pre_act": pre_bucket,
            "body": body_bucket, "turn": turn, "句长区间": (lo, hi)}


def sample_three(char, scene, rng, mood):
    """权重分层抽样：A/H/R。H 层无数据时并入 A 层。v2.6.2 支持潜台词与深层心智推演。"""
    w = STAGE_WEIGHTS[stage_of(char)]
    bk = build_buckets(char, scene, rng, mood)
    hist = char["F_hist"]
    out = {}
    # content
    a_items = [(it, wt) for it, wt in bk["content"]]
    h_items = [(it, 1.0) for it, _ in a_items] if hist["句长"]["样本"] else a_items
    r_items = [(f"扰动：句长偏移 ±{int(0.15 * (bk['句长区间'][1] - bk['句长区间'][0] + 1))}%", 1.0)]
    out["content"] = rng.weighted(
        [(it, wt) for it, wt in a_items + h_items + r_items],
        [w["attr"]] * len(a_items) + [w["hist"]] * len(h_items) + [w["seed"]] * len(r_items))
    # pre_act：A 层动作 + H 层高频动作 + R 层扰动（权重）
    n_h = len(bk["pre_act"])
    out["pre_act"] = rng.weighted(bk["pre_act"], [w["attr"]] * n_h)
    # body
    out["body"] = rng.weighted([(k, v) for k, v in bk["body"]],
                               [v * w["attr"] for _, v in bk["body"]])
    # turn
    tl, th = bk["turn"]["话轮长度"]
    out["话轮长度"] = int(rng.uniform(tl, th))
    out["回应延迟"] = bk["turn"]["回应延迟"]
    out["话题主导度"] = round(rng.uniform(*bk["turn"]["话题主导度"]), 2)

    # v2.6.2 心智推演与潜台词层 (ToM: Theory of Mind)
    proto = char["F_attr"]["性格"]["原型"]["主"]
    subtexts = {
        "社牛": "表面热络拉近关系，实则试探底线或掩盖冷场尴尬",
        "社恐": "表面唯唯诺诺应承，实则渴望尽快脱离视线或回避追问",
        "毒舌": "表面刻薄挑剔找茬，实则掩饰关切、自尊受损或试探虚实",
        "憨直": "表面认死理对对错错，实则固执维护心中唯一原则或朴素道义",
        "通透": "表面波澜不惊随顺局势，实则冷眼旁观全局走向并早有退路",
        "阴沉": "表面缄默孤僻不发一言，实则暗中清点筹码与防备背刺",
        "傲娇": "表面嫌弃抗拒拉开距离，实则内心极在意对方评价且绝不认输",
        "温柔": "表面体贴包容息事宁人，实则内心有所坚持并以柔克刚",
    }
    leakages = {
        "社牛": "话语骤然顿住半秒，随即音量拔高掩饰心虚",
        "社恐": "手指悄悄抠紧衣襟下摆，视线迅速挪向侧下方地面",
        "毒舌": "嘴角挂着讥诮弧度，但端酒/放杯的动作比平时沉了半寸",
        "憨直": "脖颈肌肉微紧，双眼直愣愣盯着对方眉心不放",
        "通透": "茶汤倾注的流线没有一丝晃动，唯有眼睑低垂未抬",
        "阴沉": "喉结极其轻微地上下滑动一下，垂在袖中的手掌缓缓虚握",
        "傲娇": "下巴抬起半寸偏向一旁，腮帮轻微咬紧了一瞬",
        "温柔": "眼睫轻颤遮住眸光，收拾手边物品的速度放慢了半拍",
    }
    out["心智推演"] = {
        "潜台词(内心动机)": subtexts.get(proto, "表面配合局势应对，实则按自身核心关切权衡利弊"),
        "动作代偿(微反应)": leakages.get(proto, "在言语交锋的停顿处有一瞬微小的视线或手指停顿")
    }
    return out


def naturalness(unit, char, scene, rng, clash_val, opponent_name, unresolved_events):
    """自然度机制：只在熵开时注入。返回提示列表。"""
    hints = []
    if not rng.entropy:
        return hints
    if clash_val >= 0.8:
        hints.append(f"打断候选：对撞强度 {clash_val}，可截断 {opponent_name} 半句")
    if rng.random() < 0.1:
        hints.append("错拍候选：先答非所问半拍，再被拉回")
    if unresolved_events and rng.random() < 0.3:
        hints.append(f"说漏嘴候选：未了事件 {unresolved_events[0]['id']} 可漏半句立刻收住（假性归因 D11）")
    if rng.random() < 0.15:
        hints.append("改口候选：说半句后补一句纠正（纠正方式随性格）")
    if unit["回应延迟"] == "不答":
        hints.append("沉默候选：用动作/物件代替回答（D5 留白对话化）")
    return hints


def generate(workdir, book, scene, names, seed, entropy):
    chars = []
    for n in names:
        c = load_char(workdir, book, n)
        if c is None:
            c = new_char(n)          # 属性缺失边界：回退默认 + fallback 标记
        chars.append(c)
    rng = RNG(seed if seed is not None else chars[0]["F_seed"]["base"], entropy)
    results = {}
    for i, c in enumerate(chars):
        mood = "应激" if ("危险" in scene or "冲突" in scene or "噩耗" in scene) else "基线"
        unit = sample_three(c, scene, rng, mood)
        hints = []
        for j, o in enumerate(chars):
            if i == j:
                continue
            cv = clash(c, o)
            if cv >= CLASH_THRESHOLD:
                o_vocab = o["F_attr"]["性格"].get("词汇", {}).get("主")
                o_exp = load_vocab().get(o_vocab, {}).get("相处体验", "")
                unit.setdefault("对撞", []).append(
                    {"对手": o["name"], "强度": cv, "方向": clash_direction(c, o),
                     **({"对手相处体验": o_exp} if o_exp else {})})
        if "对撞" not in unit:
            # 沉默死锁检测：双不答
            delays = [sample_three(x, scene, RNG(0, False), mood)["回应延迟"] for x in chars]
            if delays.count("不答") >= 2:
                unit["对撞"] = [{"方向": "沉默死锁-强制物件/动作对戏", "强度": None}]
        unresolved = [e for e in c["F_hist"]["事件表"] if e.get("状态") == "未了"]
        unit["自然度"] = naturalness(unit, c, scene, rng,
                                     (unit.get("对撞") or [{}])[0].get("强度") or 0,
                                     (unit.get("对撞") or [{}])[0].get("对手") or "对方",
                                     unresolved)
        unit["权重"] = STAGE_WEIGHTS[stage_of(c)]
        unit["阶段"] = stage_of(c)
        results[c["name"]] = unit
    return results


# ---------------------------------------------------------------- 历史与成长

def absorb(workdir, book, name, chapter_file):
    char = load_char(workdir, book, name)
    if char is None:
        char = new_char(name)
    text = open(chapter_file, "r", encoding="utf-8").read()
    quotes = re.findall(r"[“「『]([^”」』]{1,100})[”」』]", text)
    hist = char["F_hist"]
    samples = hist["句长"]["样本"]
    for q in quotes:
        L = len(q)
        mean = sum(samples) / len(samples) if samples else 0
        sigma = (sum((x - mean) ** 2 for x in samples) / len(samples)) ** 0.5 if len(samples) > 1 else 0
        if samples and sigma > 0 and abs(L - mean) > OUTLIER_SIGMA * sigma:
            hist.setdefault("离群", []).append(L)     # 离群：标记不参与权重
            continue
        samples.append(L)
    if len(samples) > 400:                             # 近 20 章窗口
        samples[:] = samples[-400:]
    arch = arch_params(char)
    for cw in arch["口癖池"]:
        cnt = text.count(cw)
        if cnt:
            hist["口癖频次"][cw] = hist["口癖频次"].get(cw, 0) + cnt
    for act in arch["动作库"]:
        cnt = text.count(act)
        if cnt:
            hist["代偿动作库"][act] = hist["代偿动作库"].get(act, 0) + cnt
    save_char(workdir, book, char)
    return char


def grow(workdir, book, name, event, direction=None):
    """登记成长事件：表层在弹性区间内摆动（滞后一步由调用方语义保证）。"""
    char = load_char(workdir, book, name)
    if char is None:
        char = new_char(name)
    p = char["F_attr"]["性格"]
    hist = char["F_hist"]
    # 回拉：本次事件前，无新刺激的章节由调用方通过 pullback 处理；此处只登记并摆动
    pullback(char)
    delta = {d: 0.0 for d in BIG5_DIMS}
    if direction:
        for d, v in direction.items():
            delta[d] = v
    else:
        # 默认：神经质 +0.05（压力事件）——仅示例，真实方向由事件类型映射表给出
        delta["N"] = 0.05
    surface = {d: clamp01(p["表层"][d] + delta[d]) for d in BIG5_DIMS}
    p["表层"], touched = clamp_band(p["根"], surface)
    hist["事件表"].append({
        "id": f"E-{event}", "热度": 0.5, "状态": "未了",
        "登记": datetime.date.today().isoformat(),
        "表层触顶": touched,
    })
    if touched:
        print(f"  [advisory] 表层触顶（{','.join(touched)}）——该角色被逼到性格极限，可写不可过")
    save_char(workdir, book, char)
    return char


def pullback(char):
    """无新刺激时表层向根回归。"""
    p = char["F_attr"]["性格"]
    s = {}
    for d in BIG5_DIMS:
        if p["表层"][d] > p["根"][d]:
            s[d] = max(p["根"][d], p["表层"][d] - PULLBACK)
        elif p["表层"][d] < p["根"][d]:
            s[d] = min(p["根"][d], p["表层"][d] + PULLBACK)
        else:
            s[d] = p["表层"][d]
    p["表层"] = s


def root_rewrite(workdir, book, name, big5, declare):
    """根性格改写：仅限作者声明，全书 ≤2 次；强制历史窗口重置。"""
    char = load_char(workdir, book, name)
    if char is None:
        print("[错误] 角色不存在，请先 init"); return None
    hist = char["F_hist"]
    if hist["根改写次数"] >= ROOT_REWRITE_MAX:
        print(f"[拒绝] 根改写已达上限 {ROOT_REWRITE_MAX} 次/书（根性格终生不变）"); return None
    if not declare:
        print("[拒绝] 无作者声明（--declare），引擎不允许事件改根"); return None
    p = char["F_attr"]["性格"]
    p["根"] = {d: clamp01(float(big5[d])) for d in BIG5_DIMS}
    p["表层"] = dict(p["根"])
    p["根声明"] = declare
    hist["根改写次数"] += 1
    hist["句长"]["样本"] = []            # 历史窗口重置：旧人不压新人
    hist["口癖频次"] = {}
    hist["代偿动作库"] = {}
    hist["事件表"] = []
    save_char(workdir, book, char)
    print(f"[OK] 根性格已改写（{declare}），历史窗口已重置，第 {hist['根改写次数']} 次/{ROOT_REWRITE_MAX}")
    return char


# ---------------------------------------------------------------- 并发仲裁

def arbitrate(triggers):
    """triggers: [(角色, 类型, 优先级)] → 胜者清单（同角色多触发取最高，同优先未出声者优先）。"""
    order = {"场景型": 5, "事件型": 4, "关系型": 3, "性格冲突型": 2, "随机型": 1}
    winners, losers = {}, []
    for name, typ, spoken in triggers:
        pri = order.get(typ, 0)
        if name in winners and winners[name][0] > pri:
            losers.append((name, typ, "同角色降级待触发池"))
            continue
        winners[name] = (pri, typ, spoken)
    # 同级：本场未出声者优先 → 简化：保持先到先得（种子决胜由调用方处理）
    return [(n, v[1]) for n, v in winners.items()], losers


# ---------------------------------------------------------------- CLI 与自测

def selftest():
    import tempfile, shutil
    ok = 0
    fail = []
    tmp = tempfile.mkdtemp(prefix="dlg_engine_")
    book = "回归"
    os.makedirs(os.path.join(tmp, ".novel_state", book), exist_ok=True)

    def t(cond, name):
        nonlocal ok
        if cond:
            ok += 1
        else:
            fail.append(name)

    # 1 属性缺失回退
    c = new_char("无卡角色")
    t(c["F_attr"]["性格"]["fallback"] is True, "属性缺失回退+标记")
    # 2 空历史冷启动权重
    t(stage_of(c) == "首章" and STAGE_WEIGHTS["首章"]["attr"] == 0.60, "空历史冷启动")
    # 3 自定义坐标跳过原型
    c2 = new_char("自定义", big5={"O": 0.1, "C": 0.1, "E": 0.1, "A": 0.1, "N": 0.9})
    t(c2["F_attr"]["性格"]["fallback"] is False, "自定义坐标不标记fallback")
    # 4 对撞强度公式
    a, b = new_char("甲", proto="社牛"), new_char("乙", proto="社恐")
    t(clash(a, b) >= 0.25, "对撞强度（社牛×社恐）")
    # 5 双低宜人冲突风险
    low1, low2 = new_char("丙", big5={"O": 0.5, "C": 0.5, "E": 0.5, "A": 0.2, "N": 0.5}), \
                 new_char("丁", big5={"O": 0.5, "C": 0.5, "E": 0.4, "A": 0.1, "N": 0.5})
    t(clash_direction(low1, low2) == "双低宜人-边界线对白", "双低宜人冲突风险")
    # 6 可复现：熵关两次一致
    save_char(tmp, book, a); save_char(tmp, book, b)
    r1 = generate(tmp, book, "闲聊", ["甲", "乙"], seed=42, entropy=False)
    r2 = generate(tmp, book, "闲聊", ["甲", "乙"], seed=42, entropy=False)
    t(json.dumps(r1, sort_keys=True) == json.dumps(r2, sort_keys=True), "熵关可复现")
    # 7 熵开有扰动
    r3 = generate(tmp, book, "闲聊", ["甲", "乙"], seed=42, entropy=True)
    t(json.dumps(r1, sort_keys=True) != json.dumps(r3, sort_keys=True), "熵开有扰动")
    # 8 表层弹性+触顶
    for _ in range(12):
        grow(tmp, book, "乙", "连续打击", direction={"N": 0.2})
    c乙 = load_char(tmp, book, "乙")
    root, surf = c乙["F_attr"]["性格"]["根"], c乙["F_attr"]["性格"]["表层"]
    t(all(abs(surf[d] - root[d]) <= SURFACE_BAND + 1e-9 for d in BIG5_DIMS), "表层弹性区间")
    t(any("N" in e["表层触顶"] for e in c乙["F_hist"]["事件表"]), "表层触顶advisory")
    # 9 回拉
    before = dict(surf)
    pullback(c乙)
    after = c乙["F_attr"]["性格"]["表层"]
    t(after["N"] <= before["N"] + 1e-9 and abs(after["N"] - root["N"]) < abs(before["N"] - root["N"]),
      "回拉向根回归")
    # 10 根不改写拒绝
    r = root_rewrite(tmp, book, "乙", {"O": 0.9, "C": 0.9, "E": 0.9, "A": 0.9, "N": 0.1}, declare=None)
    t(r is None and c乙["F_attr"]["性格"]["根"] == load_char(tmp, book, "乙")["F_attr"]["性格"]["根"],
      "无声明改根被拒")
    # 11 根改写声明通道
    r = root_rewrite(tmp, book, "乙", {"O": 0.9, "C": 0.9, "E": 0.9, "A": 0.9, "N": 0.1}, declare="黑化")
    t(r is not None and load_char(tmp, book, "乙")["F_attr"]["性格"]["根"]["N"] == 0.1, "声明改根生效")
    # 12 离群样本标记
    cc = new_char("离群测试", proto="温柔")
    cc["F_hist"]["句长"]["样本"] = [10, 11, 9, 12, 10]
    save_char(tmp, book, cc)
    ch = os.path.join(tmp, "章.md")
    open(ch, "w", encoding="utf-8").write("他说：“" + "很" * 50 + "。”")
    absorb(tmp, book, "离群测试", ch)
    t("离群" in load_char(tmp, book, "离群测试")["F_hist"], "离群±3σ标记不参与")
    # 13 并发仲裁
    winners, losers = arbitrate([("甲", "事件型", False), ("甲", "随机型", False), ("乙", "场景型", True)])
    t(dict(winners).get("甲") == "事件型" and losers, "并发仲裁（同角色取最高+降级）")
    # 14 沉默死锁
    yin1, yin2 = new_char("阴一", proto="阴沉"), new_char("阴二", proto="阴沉")
    save_char(tmp, book, yin1); save_char(tmp, book, yin2)
    rr = generate(tmp, book, "沉默的夜", ["阴一", "阴二"], seed=7, entropy=False)
    t(any("死锁" in (u.get("对撞") or [{}])[0].get("方向", "") for u in rr.values()),
      "沉默死锁强制物件/动作对戏")
    # 15 八型差异化（熵关，句长区间/延迟/主导可区分）
    sigs = {}
    for proto in ARCHETYPES:
        ch_ = new_char(proto, proto=proto)
        save_char(tmp, book, ch_)
        u = generate(tmp, book, "被当面同情", [proto], seed=1, entropy=False)[proto]
        sigs[proto] = (u["回应延迟"], round(u["话题主导度"], 1), u["话轮长度"])
    t(len(set(sigs.values())) >= 6, f"八型差异化可辨 {len(set(sigs.values()))}/8")
    # ---- v2.5.1 词汇参数层用例 ----
    # 16 词汇库加载
    vocab = load_vocab()
    t(len(vocab) >= 100, f"词汇库加载 {len(vocab)} 词 ≥100")
    # 17 画像→坐标映射（傲娇：E低 A中 C中 稳中低 O中 → N=1-0.35=0.65）
    c_aojiao = img_to_coords("外向低、宜人中、尽责中、情绪稳中低、开放中")
    t(c_aojiao is not None and abs(c_aojiao["N"] - 0.65) < 1e-9 and abs(c_aojiao["E"] - 0.225) < 1e-9,
      "画像五档→坐标映射（含情绪稳→N反向）")
    # 18 词汇合成：傲娇+温柔 → A 高于傲娇独词
    c_syn = synth_coords("傲娇", ["温柔"])
    c_aojiao_only = synth_coords("傲娇", None)
    t(c_syn is not None and c_aojiao_only is not None and c_syn["A"] > c_aojiao_only["A"],
      "词汇合成（傲娇+温柔宜人性上移）")
    # 19 劣化自动展开（风险列）
    risk = vocab_risk("傲娇")
    t(any("沟通成本" in r for r in risk), f"劣化自动展开：{risk}")
    # 20 B12 贴标签检测
    lbl = check_label("他是个傲娇，嘴上说着不要。", list(vocab.keys()))
    t("傲娇" in lbl, "B12 贴标签命中")
    lbl2 = check_label("他今天话不多，只是笑了笑。", list(vocab.keys()))
    t(not lbl2, "B12 正常叙述不误报")
    # 21 init --词汇 合成落卡
    cw = new_char("傲娇温柔体", vocab_main="傲娇", vocab_aux=["温柔"])
    t(cw["F_attr"]["性格"]["词汇"]["主"] == "傲娇"
      and cw["F_attr"]["性格"]["根"]["A"] > 0.55 and cw["F_attr"]["性格"]["根"]["N"] < 0.68,
      "词汇合成坐标落根（A上移/N下降）")
    # ---- v2.6.2 心智推演与潜台词用例 ----
    # 22 心智推演结构存在且包含潜台词与动作代偿
    u_tom = generate(tmp, book, "试探对决", ["傲娇温柔体"], seed=42, entropy=False)["傲娇温柔体"]
    t("心智推演" in u_tom and "潜台词(内心动机)" in u_tom["心智推演"]
      and "动作代偿(微反应)" in u_tom["心智推演"], "v2.6.2 ToM心智推演生成完整")
    # 23 毒舌原型潜台词与动作代偿特异性
    c_dushe = new_char("毒舌测试", proto="毒舌")
    save_char(tmp, book, c_dushe)
    u_ds = generate(tmp, book, "讽刺场景", ["毒舌测试"], seed=10, entropy=False)["毒舌测试"]
    t("掩饰" in u_ds["心智推演"]["潜台词(内心动机)"]
      or "自尊" in u_ds["心智推演"]["潜台词(内心动机)"]
      or "试探" in u_ds["心智推演"]["潜台词(内心动机)"], "毒舌潜台词意图符合预期")
    shutil.rmtree(tmp, ignore_errors=True)
    print(f"selftest：{ok} 通过 / {len(fail)} 失败")
    for f in fail:
        print("  FAIL:", f)
    return ok, fail


def main():
    ap = argparse.ArgumentParser(description="差异化对话引擎 v2.5.0")
    ap.add_argument("--workdir", "-w", default=os.getcwd(), help="小说工作目录")
    ap.add_argument("--book", default=None)
    sub = ap.add_subparsers(dest="action")

    p1 = sub.add_parser("init"); p1.add_argument("--name", required=True)
    p1.add_argument("--原型", dest="proto", default=None)
    p1.add_argument("--big5", default=None, help="O,C,E,A,N 逗号分隔")
    p1.add_argument("--词汇", dest="vocab", default=None, help="词汇参数库主词，如 傲娇")
    p1.add_argument("--辅词", dest="aux", default="", help="逗号分隔辅词，如 温柔,体贴")
    p2 = sub.add_parser("gen"); p2.add_argument("--scene", default="闲聊")
    p2.add_argument("--chars", required=True, help="逗号分隔")
    p2.add_argument("--seed", type=int, default=None); p2.add_argument("--entropy", default="on")
    p3 = sub.add_parser("absorb"); p3.add_argument("--chapter-file", required=True)
    p3.add_argument("--name", required=True)
    p4 = sub.add_parser("grow"); p4.add_argument("--event", required=True)
    p4.add_argument("--name", required=True)
    p5 = sub.add_parser("root"); p5.add_argument("--name", required=True)
    p5.add_argument("--big5", required=True); p5.add_argument("--declare", default=None)
    p6 = sub.add_parser("show"); p6.add_argument("--name", required=True)
    sub.add_parser("selftest")
    args = ap.parse_args()

    if args.action == "selftest":
        ok, fail = selftest()
        sys.exit(0 if not fail else 1)

    workdir = os.path.abspath(args.workdir)
    book = args.book or os.path.basename(workdir)

    if args.action == "init":
        big5 = None
        if args.big5:
            big5 = {d: float(v) for d, v in zip(BIG5_DIMS, args.big5.split(","))}
        c = new_char(args.name, args.proto, big5,
                     vocab_main=args.vocab,
                     vocab_aux=[x.strip() for x in args.aux.split(",") if x.strip()] or None)
        save_char(workdir, book, c)
        print(f"[init] {c['name']}：根={c['F_attr']['性格']['根']} "
              f"原型={c['F_attr']['性格']['原型']['主']} "
              f"词汇={c['F_attr']['性格'].get('词汇')} fallback={c['F_attr']['性格']['fallback']}")
    elif args.action == "gen":
        names = [n.strip() for n in args.chars.split(",")]
        res = generate(workdir, book, args.scene, names, args.seed,
                       args.entropy.lower() not in ("off", "false", "0"))
        print("（以下为生成候选与抽样参数，可取用/改写/忽略；历史统计来自 absorb 样本）")
        for n, u in res.items():
            print(f"\n[{n}] 阶段={u['阶段']} 权重={u['权重']}")
            print(f"  内容桶候选：{u['content']}")
            print(f"  说前动作候选：{u['pre_act']}")
            print(f"  身体描写候选：{u['body']}")
            print(f"  话轮抽样：长度 {u['话轮长度']} 句 / 延迟 {u['回应延迟']} / 主导 {u['话题主导度']}")
            if u.get("心智推演"):
                print(f"  心智推演(ToM)：潜台词 -> {u['心智推演']['潜台词(内心动机)']}")
                print(f"                 动作代偿 -> {u['心智推演']['动作代偿(微反应)']}")
            if u.get("对撞"):
                print(f"  对撞：{u['对撞']}")
            if u.get("自然度"):
                print(f"  自然度提示：{u['自然度']}")
    elif args.action == "absorb":
        absorb(workdir, book, args.name, args.chapter_file)
        c = load_char(workdir, book, args.name)
        mean, sigma = hist_stats(c)
        print(f"[absorb] {args.name}：样本 {len(c['F_hist']['句长']['样本'])} 均值 {mean} σ {sigma} "
              f"阶段 {stage_of(c)}")
        print("  （以上为本章历史样本统计，供后续生成参考与差异报告比较）")
    elif args.action == "grow":
        grow(workdir, book, args.name, args.event)
        c = load_char(workdir, book, args.name)
        print(f"[grow] {args.name}：表层={c['F_attr']['性格']['表层']} 根={c['F_attr']['性格']['根']}")
    elif args.action == "root":
        root_rewrite(workdir, book, args.name,
                     {d: float(v) for d, v in zip(BIG5_DIMS, args.big5.split(","))}, args.declare)
    elif args.action == "show":
        c = load_char(workdir, book, args.name)
        print(json.dumps(c, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
