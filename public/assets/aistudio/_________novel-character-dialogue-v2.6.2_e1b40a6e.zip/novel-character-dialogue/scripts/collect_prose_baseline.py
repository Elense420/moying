#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小说角色对话 · 正文基准采集器（设计方案 模块 1/4 · v2.6.0）

从语料库正文采样，统计题材级正文基准指标，产出 `references/题材基准表.md`。
基准表是 prose_metrics.py 的对照数据源：写作后机检正文是否落在题材基准区间内。

统计口径（v2.6.0 校准）：**按章节级样本统计**，而非按书中位聚合。
前者反映单章的自然波动范围（用于验收单章）；后者区间过窄，会把大量正常章节判为偏离
（实测：按书中位聚合时"含对白段占比"误报率 31%，按章节级 5%–95% 分位后降至合理水平）。

采集指标（按题材聚合章节级分位）：
  单章字数 / 句长中位 / 段长中位 / 含对白段占比 / 纯对白段占比 /
  比喻密度（"像/如同/宛如"每千字）/ 连续纯对白段上限

只读语料库，不修改任何源文件。

用法：
  python scripts/collect_prose_baseline.py --kb "<语料库路径>" --books-per-genre 5
  python scripts/collect_prose_baseline.py --kb "<语料库路径>" --genre 01-玄幻仙侠 --chapters 12
  python scripts/collect_prose_baseline.py --kb "<语料库路径>" --out references/题材基准表.md
"""

import io
import os
import re
import sys
import glob
import json
import argparse
import statistics

CJK = re.compile(r"[\u4e00-\u9fff]")
QUOTE_PAIR = re.compile(r"[\u201c\u300c]([^\u201d\u300d]{1,200})[\u201d\u300d]")
HAS_QUOTE = re.compile(r"[\u201c\u300d\u300c\u300d]")
# 纯对白段：整段就是一个引号对（可带尾部说话人标注以外的极短成分）
PURE_DIALOGUE = re.compile(r"^[\u201c\u300c][^\u201d\u300d]*[\u201d\u300d][\u3002\uff01\uff1f\u2026\s]*$")
SIMILE = re.compile(r"(?:像|如同|宛如|仿佛|好似|犹如)")
SENT_SPLIT = re.compile(r"[。！？]")

# ---------------------------------------------------------------- 情感维度（v2.6.1 新增）
# 内心活动：视角人物当下的心理活动（合法；区别于"多年后他才明白"式作者已知识）
INNER = re.compile(
    r"(?:心想|暗道|暗想|心道|心中|心里|心底|内心|脑海里|脑中|寻思|琢磨|盘算|思忖|"
    r"念头|思索|疑惑|纳闷|不解|犹豫|迟疑|权衡|合计|暗自|自问|"
    r"明白过来|意识到|反应过来)"
)
# 即时情绪：事件发生后的第一反应（原作普遍做法，非抒情式铺陈）
EMO_IMMEDIATE = re.compile(
    r"(?:心中一|心头一|心里一|心底一|又[\u4e00-\u9fff]又[\u4e00-\u9fff]|"
    r"松了口气|松了一口气|大喜|狂喜|惊恐|惊喜|一惊|一喜|一怒|一急|一慌|"
    r"欣喜|忿忿|恼怒|愕然|骇然|释然|怅然|黯然|"
    r"长长地?吐了口气|倒吸了口?凉气)"
)

DEFAULT_GENRES = [
    "01-玄幻仙侠", "02-都市职场", "03-历史架空", "04-科幻末世",
    "05-悬疑灵异", "06-奇幻西幻", "07-游戏竞技", "08-言情古言",
]


def find_skill_root():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(here)


def _is_book_dir(name):
    """跳过索引/脚本/隐藏目录。"""
    if name.startswith(".") or name.startswith("_"):
        return False
    if re.match(r"^0[0-9]_", name):          # 00_本书MOC.md 之类
        return False
    if name.endswith(".md"):
        return False
    if name in ("__pycache__", "audit_out", "backups"):
        return False
    return True


def pick_volume_files(book_dir, max_volumes=2):
    """取本书正文分卷里体量适中的若干卷文件（避免只取开头）。"""
    vdir = os.path.join(book_dir, "01-小说正文", "正文分卷")
    if not os.path.isdir(vdir):
        return []
    files = []
    for f in sorted(os.listdir(vdir)):
        if not f.endswith(".md"):
            continue
        if "占位" in f or "索引" in f:
            continue
        files.append(os.path.join(vdir, f))
    if not files:
        return []
    # 取中间位置的卷，覆盖中段文风（第1卷常是黄金三章，不代表全书平均）
    mid = len(files) // 2
    picks = []
    for off in (0, mid):
        i = min(max(mid + off - 1, 0), len(files) - 1) if off else min(mid, len(files) - 1)
        if files[i] not in picks:
            picks.append(files[i])
    return picks[:max_volumes]


def split_paragraphs(text):
    paras = []
    for p in text.split("\n"):
        p = p.strip()
        if not p or p.startswith("#") or p.startswith("|") or p.startswith(">"):
            continue
        if len(p) < 4:
            continue
        paras.append(p)
    return paras


def split_chapters(text):
    """按 '第N章' 标题切章；返回 [(title, body)]。"""
    idx = [m.start() for m in re.finditer(r"第[0-9一二三四五六七八九十百千]+章", text)]
    out = []
    for i in range(len(idx) - 1):
        seg = text[idx[i]:idx[i + 1]]
        out.append(seg)
    return out


def measure_text(text):
    """单份文本（整卷）的指标集合。用于兼容旧调用；章节级采集请用 measure_chapters。"""
    paras = split_paragraphs(text)
    if not paras:
        return None
    cjk = len(CJK.findall(text))
    if cjk < 2000:
        return None

    plens = [len(p) for p in paras]
    sents = []
    for p in paras:
        sents += [s for s in SENT_SPLIT.split(p) if len(s.strip()) > 1]
    slens = [len(s) for s in sents] or [0]

    has_dlg = sum(1 for p in paras if HAS_QUOTE.search(p) and QUOTE_PAIR.search(p))
    pure = sum(1 for p in paras if PURE_DIALOGUE.match(p))

    simile = len(SIMILE.findall(text))

    run = best = 0
    for p in paras:
        if PURE_DIALOGUE.match(p):
            run += 1
            best = max(best, run)
        else:
            run = 0

    chs = []
    for seg in split_chapters(text):
        n = len(CJK.findall(seg))
        if n > 300:
            chs.append(n)

    return {
        "字数": cjk,
        "段数": len(paras),
        "单章字数": int(statistics.median(chs)) if chs else None,
        "句长中位": int(statistics.median(slens)),
        "段长中位": int(statistics.median(plens)),
        "含对白段占比": round(has_dlg * 100.0 / len(paras), 1),
        "纯对白段占比": round(pure * 100.0 / len(paras), 1),
        "比喻密度": round(simile * 1000.0 / cjk, 2),
        "连续纯对白上限": best,
    }


def measure_chapter(seg):
    """单章指标（章节级统计的基本单位）。正文不足的章返回 None。"""
    paras = split_paragraphs(seg)
    cjk = len(CJK.findall(seg))
    if not paras or cjk < 600:          # 单章至少 600 汉字才计入
        return None

    plens = [len(p) for p in paras]
    sents = []
    for p in paras:
        sents += [s for s in SENT_SPLIT.split(p) if len(s.strip()) > 1]
    slens = [len(s) for s in sents] or [0]

    has_dlg = sum(1 for p in paras if HAS_QUOTE.search(p) and QUOTE_PAIR.search(p))
    pure = sum(1 for p in paras if PURE_DIALOGUE.match(p))
    simile = len(SIMILE.findall(seg))

    run = best = 0
    for p in paras:
        if PURE_DIALOGUE.match(p):
            run += 1
            best = max(best, run)
        else:
            run = 0

    # ---- 情感维度（v2.6.1）----
    inner = len(INNER.findall(seg))
    emo = len(EMO_IMMEDIATE.findall(seg))
    quotes = [q for q in QUOTE_PAIR.findall(seg) if 2 <= len(q) <= 300]
    qlens = sorted(len(q) for q in quotes)
    q_median = int(statistics.median(qlens)) if qlens else 0
    long_ratio = round(sum(1 for x in qlens if x >= 30) * 100.0 / len(qlens), 1) if qlens else 0.0

    return {
        "单章字数": cjk,
        "句长中位": int(statistics.median(slens)),
        "段长中位": int(statistics.median(plens)),
        "含对白段占比": round(has_dlg * 100.0 / len(paras), 1),
        "纯对白段占比": round(pure * 100.0 / len(paras), 1),
        "比喻密度": round(simile * 1000.0 / cjk, 2),
        "连续纯对白上限": best,
        # 情感维度：密度为每千汉字次数（‰）
        "内心活动密度": round(inner * 1000.0 / cjk, 2),
        "即时情绪密度": round(emo * 1000.0 / cjk, 2),
        "台词长度中位": q_median,
        "长台词占比": long_ratio,
    }


def chapters_from(text, max_chapters):
    """从卷文件切章并逐章测量，返回指标列表（跳过章首/章末不完整章）。"""
    chs = split_chapters(text)
    if len(chs) < 4:
        return []
    # 跳过首章（黄金三章文风特殊）与末章（可能截断）
    body = chs[1:-1] if len(chs) > 6 else chs
    out = []
    for seg in body[:max_chapters]:
        m = measure_chapter(seg)
        if m:
            out.append(m)
    return out


def collect_genre(kb, genre, books_per_genre, chapters_per_book=12):
    """按章节级样本采集题材基准。返回 (章节指标列表, 采到书名的列表)。"""
    gdir = os.path.join(kb, genre)
    if not os.path.isdir(gdir):
        return [], []
    books = sorted(b for b in os.listdir(gdir)
                   if _is_book_dir(b) and os.path.isdir(os.path.join(gdir, b)))
    picked, chapter_metrics = [], []
    for b in books:
        if len(picked) >= books_per_genre:
            break
        vols = pick_volume_files(os.path.join(gdir, b))
        if not vols:
            continue
        got = []
        for v in vols:
            try:
                t = io.open(v, encoding="utf-8").read()
            except Exception:
                continue
            got += chapters_from(t, chapters_per_book)
        if got:
            picked.append(b)
            chapter_metrics += got
    return chapter_metrics, picked


def aggregate(chapter_metrics, keys):
    """跨章节抽取分位阶梯（p1/p5/p10/p25/p50/p75/p90/p95/p99）。

    用分位阶梯而非单一区间：prose_metrics.py 据此计算实测值的**百分位位置**，
    比二值判定信息量更大（"处于第 2 百分位"比"偏低"更可用于判断）。
    验收带取 p1–p99（极端越界），避免把正常文风波动判为偏离
    （实测：p5–p95 对未参与建表的书误报 15%–22%）。
    """
    out = {}
    # 小数量级指标（‰ 密度、比例）保留两位小数；整数量级指标（字数）取整
    FLOAT_KEYS = {"内心活动密度", "即时情绪密度", "长台词占比", "比喻密度",
                  "含对白段占比", "纯对白段占比"}
    for k in keys:
        vals = sorted(m[k] for m in chapter_metrics if m.get(k) is not None)
        if not vals:
            out[k] = None
            continue
        q = lambda p: vals[min(len(vals) - 1, max(0, int(len(vals) * p)))]
        conv = (lambda x: round(x, 2)) if k in FLOAT_KEYS else int
        ladder = {f"p{int(p*100)}": conv(q(p))
                  for p in (0.01, 0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99)}
        out[k] = {
            "中位": ladder["p50"],
            "下限": ladder["p1"],
            "上限": ladder["p99"],
            "分位阶梯": ladder,
            "样本数": len(vals),
        }
    return out


def write_markdown(dest, all_stats, meta):
    lines = []
    lines.append("# 题材基准表（正文质量对照数据）")
    lines.append("")
    lines.append("> 由 `scripts/collect_prose_baseline.py` 从语料库正文**按章节级样本**统计生成，供 `scripts/prose_metrics.py` 对照。")
    lines.append("> 采集方式：每题材抽 N 本 × 每本抽 M 章（跳首章与末章），跨章节取 2% / 50% / 98% 分位（验收带：反映极端越界，避免把正常文风波动判为偏离）。")
    lines.append("> 区间含义：**单章正文的自然波动范围**——落在区间内即与参照语料同一量级。")
    lines.append(f"> 语料库：{meta['kb']}")
    lines.append(f"> 采样：{meta['books']} 本 / {meta['chapters']} 章 / {meta['genres']} 题材")
    lines.append("")
    lines.append("**用法**：写后跑 `prose_metrics.py` 机检，指标落在下表区间内视为与参照语料同一量级；")
    lines.append("越界只提示偏离（advisory），是否调整由作者决定。")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 一、各题材基准")
    lines.append("")
    lines.append("| 题材 | 采样 | 单章字数 | 句长中位 | 段长中位 | 含对白段% | 纯对白段% | 比喻密度‰ | 连续纯对白上限 | 内心活动‰ | 即时情绪‰ | 台词长度中位 | 长台词占比% |")
    lines.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|")

    keys = ["单章字数", "句长中位", "段长中位", "含对白段占比", "纯对白段占比",
            "比喻密度", "连续纯对白上限",
            "内心活动密度", "即时情绪密度", "台词长度中位", "长台词占比"]

    def fmt(d):
        if not d:
            return "—"
        return f"{d['中位']}（{d['下限']}–{d['上限']}）"

    for genre, payload in all_stats.items():
        if not payload:
            lines.append(f"| {genre} | 无数据 | — | — | — | — | — | — | — |")
            continue
        agg = payload["聚合"]
        lines.append("| {} | {}本/{}章 | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} | {} |".format(
            genre, payload["书数"], payload["章数"],
            fmt(agg.get("单章字数")), fmt(agg.get("句长中位")), fmt(agg.get("段长中位")),
            fmt(agg.get("含对白段占比")), fmt(agg.get("纯对白段占比")),
            fmt(agg.get("比喻密度")), fmt(agg.get("连续纯对白上限")),
            fmt(agg.get("内心活动密度")), fmt(agg.get("即时情绪密度")),
            fmt(agg.get("台词长度中位")), fmt(agg.get("长台词占比")),
        ))

    # 分位阶梯（机检据此报告实测值的百分位位置）
    lines.append("")
    lines.append("## 二、分位阶梯（机检取用）")
    lines.append("")
    lines.append("> `prose_metrics.py` 读取本表后，报告实测值落在语料分布的**第几百分位**，")
    lines.append("> 而非只给「在/不在区间」——百分位更能说明偏离程度。")
    lines.append("")
    have_ladder = [g for g, p in all_stats.items()
                   if p and p["聚合"].get("句长中位") and "分位阶梯" in p["聚合"]["句长中位"]]
    if have_ladder:
        lines.append("```json")
        ladder_dump = {}
        for g, p in all_stats.items():
            if not p:
                continue
            ladder_dump[g] = {
                k: v["分位阶梯"] for k, v in p["聚合"].items()
                if v and "分位阶梯" in v
            }
        lines.append(json.dumps(ladder_dump, ensure_ascii=False, indent=1))
        lines.append("```")
    else:
        lines.append("（本次采集未记录分位阶梯，请重跑 collect_prose_baseline.py）")

    lines.append("")
    lines.append("## 三、跨题材总区间（不区分题材时的兜底基准）")
    lines.append("")
    merged = {}
    for k in keys:
        vals = []
        for payload in all_stats.values():
            if payload and payload["聚合"].get(k):
                vals.append(payload["聚合"][k]["中位"])
        if vals:
            vs = sorted(vals)
            merged[k] = {
                "中位": int(statistics.median(vs)),
                "下限": vs[max(0, int(len(vs) * 0.02))],
                "上限": vs[min(len(vs) - 1, int(len(vs) * 0.98))],
            }
    lines.append("| 指标 | 中位 | 参考区间 |")
    lines.append("|---|---|---|")
    label = {
        "单章字数": "单章字数", "句长中位": "句长中位（字）", "段长中位": "段长中位（字）",
        "含对白段占比": "含对白段占比（%）", "纯对白段占比": "纯对白段占比（%）",
        "比喻密度": "比喻密度（处/千字）", "连续纯对白上限": "连续纯对白段上限",
        "内心活动密度": "内心活动密度（‰）", "即时情绪密度": "即时情绪密度（‰）",
        "台词长度中位": "台词长度中位（字）", "长台词占比": "长台词占比（%）",
    }
    for k in keys:
        if k in merged:
            d = merged[k]
            lines.append(f"| {label[k]} | {d['中位']} | {d['下限']}–{d['上限']} |")

    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## 四、指标含义与处置")
    lines.append("")
    lines.append("| 指标 | 含义 | 判定方式 | 越界处置 |")
    lines.append("|---|---|---|---|")
    lines.append("| 单章字数 | 单章正文汉字量 | 双侧 | 低于下限提示章内节拍可能未展开；高于上限提示可能未收束 |")
    lines.append("| 句长中位 | 以。！？切分的句长中位数 | 双侧 | 偏低提示短句堆叠（电报体倾向）；偏高提示长句拖节奏 |")
    lines.append("| 段长中位 | 自然段长度中位数 | 双侧 | 偏低提示段落过碎；偏高提示大段未拆分 |")
    lines.append("| 含对白段占比 | 含引号台词的自然段比例 | 双侧 | 偏低提示信息全靠叙述；偏高提示对白承载过多 |")
    lines.append("| 纯对白段占比 | 整段仅一句台词的比例 | 仅上限 | 超高提示缺少动作/环境/身体承接（对话未嵌入正文） |")
    lines.append("| 比喻密度 | 像/如同/宛如等喻词每千字出现次数 | 仅上限 | 超高提示修辞堆砌 |")
    lines.append("| 连续纯对白上限 | 最长连续纯对白段数 | 仅上限 | 超高提示一问一答电报体（可补承接或合并） |")
    lines.append("| 内心活动密度 | 视角人物当下心理活动每千字次数 | 双侧 | 偏低提示角色只有外在行为、缺内在反应（见 references/内心活动层.md） |")
    lines.append("| 即时情绪密度 | 事件后的第一反应（心中一X/又X又Y 等）每千字次数 | 双侧 | 偏低提示情绪反应缺失、读感平淡 |")
    lines.append("| 台词长度中位 | 引号内台词字符数中位数 | 双侧 | 偏低提示台词过短、承载不足 |")
    lines.append("| 长台词占比 | ≥30 字台词占全部台词的比例 | 双侧 | 偏低提示缺少「信息+态度+关系」三层台词 |")
    lines.append("")
    lines.append("> 全部指标默认只出 advisory：记录偏离与证据，由作者决定是否调整。")
    lines.append("> 项目可自行登记为规则（登记方式见 `角色一致性检查清单.md` 与 `豁免判定规则.md`）。")
    lines.append("")

    with io.open(dest, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines))


def main():
    ap = argparse.ArgumentParser(description="正文基准采集器（从语料库统计题材级正文指标）")
    ap.add_argument("--kb", required=True, help="语料库根目录（含 01-玄幻仙侠 等题材目录）")
    ap.add_argument("--genre", action="append", default=None,
                    help="指定题材目录名（可重复）；不传则跑全部 8 题材")
    ap.add_argument("--books-per-genre", type=int, default=5, help="每题材采样书数（默认 5）")
    ap.add_argument("--chapters", type=int, default=12, help="每本采样章节数（默认 12，跳首末章）")
    ap.add_argument("--out", default=None,
                    help="输出 md（默认 <技能根>/references/题材基准表.md）")
    ap.add_argument("--json", default=None, help="可选：同时输出 json 供程序消费")
    args = ap.parse_args()

    kb = os.path.abspath(args.kb)
    if not os.path.isdir(kb):
        print(f"[错误] 语料库目录不存在：{kb}")
        sys.exit(1)
    genres = args.genre or [g for g in DEFAULT_GENRES if os.path.isdir(os.path.join(kb, g))]
    if not genres:
        print(f"[错误] 在 {kb} 下未找到题材目录")
        sys.exit(1)

    dest = args.out or os.path.join(find_skill_root(), "references", "题材基准表.md")

    keys = ["单章字数", "句长中位", "段长中位", "含对白段占比", "纯对白段占比",
            "比喻密度", "连续纯对白上限",
            "内心活动密度", "即时情绪密度", "台词长度中位", "长台词占比"]
    all_stats = {}
    total_books = total_chapters = 0
    print(f"采集语料库：{kb}")
    for g in genres:
        chapter_metrics, picked = collect_genre(kb, g, args.books_per_genre, args.chapters)
        if not chapter_metrics:
            print(f"  {g}：无可用正文")
            all_stats[g] = None
            continue
        agg = aggregate(chapter_metrics, keys)
        all_stats[g] = {"书数": len(picked), "章数": len(chapter_metrics), "聚合": agg}
        total_books += len(picked)
        total_chapters += len(chapter_metrics)
        print(f"  {g}：{len(picked)} 本 / {len(chapter_metrics)} 章  "
              f"句长 {agg['句长中位']['中位']}  单章字数 {agg['单章字数']['中位']}  "
              f"内心 {agg['内心活动密度']['中位']}‰  情绪 {agg['即时情绪密度']['中位']}‰  "
              f"台词中位 {agg['台词长度中位']['中位']}  长台词 {agg['长台词占比']['中位']}%")

    write_markdown(dest, all_stats, {"kb": kb, "books": total_books,
                                     "chapters": total_chapters, "genres": len(genres)})
    print(f"\n基准表已写出：{dest}（{total_books} 本 / {total_chapters} 章 / {len(genres)} 题材）")

    if args.json:
        with io.open(args.json, "w", encoding="utf-8", newline="\n") as f:
            json.dump(all_stats, f, ensure_ascii=False, indent=2)
        print(f"JSON 已写出：{args.json}")


if __name__ == "__main__":
    main()
