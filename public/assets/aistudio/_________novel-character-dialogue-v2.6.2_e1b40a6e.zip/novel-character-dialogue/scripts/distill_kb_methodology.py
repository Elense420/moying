#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小说角色对话 · 知识库创作方法论蒸馏（设计方案 模块 1/2 · v2.6.0）

把知识库 `09—小说创作/<题材>/<书名>/` 下的 9 篇论文级方法论文档，
按题材聚类提炼成技能可用的 `references/创作方法论-<题材>.md`，
并汇总一份跨题材通用的 `references/创作方法论-通用.md`。

为什么需要这个脚本：
  知识库 09 层是**专为"喂给大模型仿写"构建**的方法论层（每本 9 篇，含
  【原作证据】/【推断】/【方法论】三层标注与「AI 仿写可执行清单」）。
  原技能只用了语料正文，未接这一层——本脚本把方法论层接入技能。

产物结构（每题材 / 通用各一份）：
  一、结构骨架（故事大纲/主线副线）
  二、情节与节奏（剧情脉络/悬念分层/钩子）
  三、人物与对话（人物塑造）
  四、文笔与修辞（修辞手法）
  五、世界观（世界观设定）
  六、执行清单（各文档第五节的 checklist 汇总）

只读知识库；不修改源文件。

用法：
  python scripts/distill_kb_methodology.py --kb "<语料库路径>" --books-per-genre 3
  python scripts/distill_kb_methodology.py --kb "<语料库路径>" --genre 01-玄幻仙侠
  python scripts/distill_kb_methodology.py --kb "<语料库路径>" --out-dir references
"""

import io
import os
import re
import sys
import argparse

DOC_ORDER = [
    ("01-标题与大卖点.md", "标题与大卖点", "开局与卖点"),
    ("02-故事大纲.md", "故事大纲", "结构骨架"),
    ("03-剧情脉络.md", "剧情脉络", "情节与节奏"),
    ("04-主线与副线.md", "主线与副线", "主线副线"),
    ("05-世界观设定.md", "世界观设定", "世界观"),
    ("06-人物塑造与描写.md", "人物塑造与描写", "人物与对话"),
    ("07-修辞手法.md", "修辞手法", "文笔与修辞"),
    ("08-创作维度.md", "创作维度", "创作方法"),
    ("09-补充写作要点.md", "补充写作要点", "悬念与商业节奏"),
]

DEFAULT_GENRES = [
    "01-玄幻仙侠", "02-都市职场", "03-历史架空", "04-科幻末世",
    "05-悬疑灵异", "06-奇幻西幻", "07-游戏竞技", "08-言情古言",
]


def find_skill_root():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(here)


def _is_book_dir(name):
    if name.startswith(".") or name.startswith("_"):
        return False
    if name.endswith(".md"):
        return False
    return True


def read_doc(path):
    """读一篇 09 层文档，抽出「核心方法论」「忌讳与注意」「AI 仿写可执行清单」三节。"""
    try:
        t = io.open(path, encoding="utf-8").read()
    except Exception:
        return None

    def section(title_pat):
        m = re.search(r"^#{2,3}\s*" + title_pat + r".*?\n(.*?)(?=^#{2,3}\s|\Z)", t, re.S | re.M)
        return m.group(1).strip() if m else ""

    method = section(r"二、核心方法论")
    avoid = section(r"四、忌讳与注意")
    checklist = section(r"五、AI 仿写可执行清单")
    return {"method": method, "avoid": avoid, "checklist": checklist}


def extract_items(block):
    """把编号列表/项目符号列表切成条目。"""
    items = []
    for line in block.split("\n"):
        s = line.strip()
        if not s:
            continue
        m = re.match(r"^(?:[-*]|\d+[.、)])\s*(.+)$", s)
        if m:
            items.append(m.group(1).strip())
        elif items:
            items[-1] += " " + s          # 续行并入上一条
    return items


def extract_checkboxes(block):
    out = []
    for line in block.split("\n"):
        s = line.strip()
        m = re.match(r"^[-*]?\s*\[[ x]?\]\s*(.+)$", s)
        if m:
            out.append(m.group(1).strip())
    return out


def collect_genre(kb, genre, books_per_genre):
    """采集某题材下若干部书的 9 篇文档要点。"""
    gdir = os.path.join(kb, genre)
    if not os.path.isdir(gdir):
        return None
    books = sorted(b for b in os.listdir(gdir)
                   if _is_book_dir(b) and os.path.isdir(os.path.join(gdir, b)))
    picked = []
    for b in books:
        bdir = os.path.join(gdir, b)
        docs = {}
        for fname, label, group in DOC_ORDER:
            p = os.path.join(bdir, fname)
            if not os.path.exists(p):
                continue
            d = read_doc(p)
            if d and (d["method"] or d["checklist"]):
                docs[label] = {"group": group, "doc": d}
        if len(docs) >= 5:                 # 至少 5 篇才认为该书信得过
            picked.append((b, docs))
        if len(picked) >= books_per_genre:
            break
    return picked


def merge_genre(picked):
    """把多本书的同类要点聚合（去重、保留出处）。"""
    groups = {}
    for book, docs in picked:
        for label, payload in docs.items():
            g = payload["group"]
            groups.setdefault(g, {"methods": [], "avoids": [], "checks": []})
            entry = groups[g]
            for it in extract_items(payload["doc"]["method"]):
                entry["methods"].append((it, book))
            for it in extract_items(payload["doc"]["avoid"]):
                entry["avoids"].append((it, book))
            for it in extract_checkboxes(payload["doc"]["checklist"]):
                entry["checks"].append((it, book))
    return groups


def dedupe(items, limit=14):
    """按前 18 字判重，保留首次出现。"""
    seen, out = set(), []
    for it, book in items:
        key = re.sub(r"[\s\W]", "", it)[:18]
        if key in seen:
            continue
        seen.add(key)
        out.append((it, book))
        if len(out) >= limit:
            break
    return out


GROUP_ORDER = ["开局与卖点", "结构骨架", "情节与节奏", "主线副线",
               "世界观", "人物与对话", "文笔与修辞", "创作方法", "悬念与商业节奏"]


def render_genre(genre, picked):
    groups = merge_genre(picked)
    lines = []
    lines.append(f"# 创作方法论 · {genre}（知识库方法论层蒸馏）")
    lines.append("")
    lines.append("> 来源：知识库 `09—小说创作/<题材>/<书名>/` 论文级方法论文档（每本 9 篇）。")
    lines.append("> 该层由语料库构建方产出，三层证据标注：【原作证据】有原文出处 /【推断】文本分析 /【方法论】可迁移结论。")
    lines.append(f"> 本文件聚合 {len(picked)} 本：{'、'.join(b for b, _ in picked)}")
    lines.append("")
    lines.append("**定位**：这是**仿写参照与方法候选**，不是强制规范。")
    lines.append("条目保留了各书的具体做法与数值尺度（如「比喻每章 ≤5 处」是该书的尺度），")
    lines.append("跨题材时应理解为「该题材常见做法」，实际取值由项目与题材决定。")
    lines.append("> 与其他资产配合：正文质量指标见 `题材基准表.md`，机检见 `scripts/prose_metrics.py`。")
    lines.append("")
    lines.append("---")
    lines.append("")

    for g in GROUP_ORDER:
        if g not in groups:
            continue
        e = groups[g]
        lines.append(f"## {g}")
        lines.append("")
        ms = dedupe(e["methods"])
        if ms:
            lines.append("### 方法论要点")
            lines.append("")
            for it, book in ms:
                lines.append(f"- {it}")
            lines.append("")
        av = dedupe(e["avoids"], 10)
        if av:
            lines.append("### 常见失手（各书『忌讳与注意』条目）")
            lines.append("")
            for it, book in av:
                lines.append(f"- {it}")
            lines.append("")
        ck = dedupe(e["checks"], 12)
        if ck:
            lines.append("### 可执行清单")
            lines.append("")
            for it, book in ck:
                lines.append(f"- [ ] {it}")
            lines.append("")

    lines.append("---")
    lines.append("")
    lines.append("## 使用说明")
    lines.append("")
    lines.append("1. 开书前：按「结构骨架 / 主线副线」搭双引擎与卷结构。")
    lines.append("2. 写作中：按「情节与节奏 / 悬念与商业节奏」安排爽点与章末钩子。")
    lines.append("3. 每章写后：对照「可执行清单」与 `prose_metrics.py` 的指标机检。")
    lines.append("4. 条目与本项目既有记录冲突时，以项目自己登记的结构与既有正文样本为准。")
    lines.append("")
    return "\n".join(lines)


def render_general(all_picked, genres_used):
    """跨题材通用版：优先保留在 ≥2 个题材中出现的要点。

    降级规则：若可用题材不足 2 个（方法论层尚未铺开时的常见情形），
    改为聚合全部题材的要点并标注"单题材待验证"，避免通用版空转。
    """
    cross = len(genres_used) >= 2
    min_genres = 2 if cross else 1
    by_key = {}
    for genre, picked in all_picked.items():
        groups = merge_genre(picked)
        for g, e in groups.items():
            for it, book in e["methods"]:
                key = (g, re.sub(r"[\s\W]", "", it)[:16])
                by_key.setdefault(key, {"group": g, "text": it, "genres": set()})
                by_key[key]["genres"].add(genre)
            for it, book in e["checks"]:
                key = (g + "#check", re.sub(r"[\s\W]", "", it)[:16])
                by_key.setdefault(key, {"group": g, "text": it, "genres": set(), "check": True})
                by_key[key]["genres"].add(genre)

    groups = {}
    for v in by_key.values():
        if len(v["genres"]) < min_genres:
            continue
        g = v["group"]
        groups.setdefault(g, {"methods": [], "checks": []})
        (groups[g]["checks"] if v.get("check") else groups[g]["methods"]).append(
            (v["text"], len(v["genres"])))

    lines = []
    lines.append("# 创作方法论 · 跨题材通用（知识库方法论层蒸馏）")
    lines.append("")
    lines.append("> 来源：知识库 `09—小说创作/` 方法论层。")
    if cross:
        lines.append("> 取**在 ≥2 个题材中重复出现**的要点。")
    else:
        lines.append(f"> 方法论层目前仅有 {len(genres_used)} 个题材完成成文（{'、'.join(genres_used)}），")
        lines.append("> 故本版暂聚合该题材要点并标注【单题材待验证】；")
        lines.append("> 待其他题材的方法论文档补齐后重跑本脚本，即可自动升级为跨题材共性。")
    lines.append(f"> 覆盖题材：{'、'.join(genres_used)}")
    lines.append("")
    lines.append("**定位**：跨题材共性是**最稳的仿写参照**；题材特有做法见各 `创作方法论-<题材>.md`。")
    lines.append("全部条目为方法候选，不是强制规范；项目可自行登记取舍。")
    lines.append("")
    lines.append("---")
    lines.append("")

    tag = "" if cross else "【单题材待验证】"
    for g in GROUP_ORDER:
        if g not in groups:
            continue
        e = groups[g]
        if e["methods"]:
            lines.append(f"## {g}")
            lines.append("")
            for it, n in sorted(e["methods"], key=lambda x: -x[1])[:14]:
                suffix = f"（{n} 个题材出现）" if cross else tag
                lines.append(f"- {it}{suffix}")
            lines.append("")
        if e["checks"]:
            if not e["methods"]:
                lines.append(f"## {g}")
                lines.append("")
            lines.append("### 可执行清单")
            lines.append("")
            for it, n in sorted(e["checks"], key=lambda x: -x[1])[:12]:
                suffix = f"（{n} 个题材出现）" if cross else tag
                lines.append(f"- [ ] {it}{suffix}")
            lines.append("")

    lines.append("---")
    lines.append("")
    lines.append("## 三条贯穿性结论")
    lines.append("")
    lines.append("1. **双引擎**：外部升级线与内部悬念线互相咬合，每次推进都同时给「变强」与「真相」。")
    lines.append("2. **因果闭合**：每个事件都要能回答「谁受益、谁推动、引发什么」，伏笔宜埋得轻、收得重。")
    lines.append("3. **章末有因**：章尾落在具体反应、关系变化、代价或已确定的下一步，让读者有继续读的理由。")
    lines.append("")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="知识库创作方法论蒸馏（09—小说创作 层 → 技能 references）")
    ap.add_argument("--kb", required=True, help="语料库根目录")
    ap.add_argument("--genre", action="append", default=None, help="指定题材（可重复）；默认全部")
    ap.add_argument("--books-per-genre", type=int, default=3, help="每题材取几本（默认 3）")
    ap.add_argument("--out-dir", default=None, help="输出目录（默认 <技能根>/references）")
    args = ap.parse_args()

    kb = os.path.abspath(args.kb)
    method_root = os.path.join(kb, "09—小说创作")
    if not os.path.isdir(method_root):
        print(f"[错误] 未找到方法论层：{method_root}")
        print("       请确认知识库包含 `09—小说创作/` 目录。")
        sys.exit(1)

    genres = args.genre or [g for g in DEFAULT_GENRES
                            if os.path.isdir(os.path.join(method_root, g))]
    if not genres:
        print(f"[错误] {method_root} 下未找到题材目录")
        sys.exit(1)

    out_dir = args.out_dir or os.path.join(find_skill_root(), "references")
    os.makedirs(out_dir, exist_ok=True)

    all_picked = {}
    used = []
    print(f"蒸馏方法论层：{method_root}")
    for g in genres:
        picked = collect_genre(method_root, g, args.books_per_genre)
        if not picked:
            print(f"  {g}：无可用方法论文档（跳过）")
            continue
        all_picked[g] = picked
        used.append(g)
        dest = os.path.join(out_dir, f"创作方法论-{g}.md")
        with io.open(dest, "w", encoding="utf-8", newline="\n") as f:
            f.write(render_genre(g, picked))
        print(f"  {g}：{len(picked)} 本 -> {os.path.basename(dest)}")

    if not all_picked:
        print("[错误] 未采到任何方法论内容。")
        sys.exit(1)

    dest = os.path.join(out_dir, "创作方法论-通用.md")
    with io.open(dest, "w", encoding="utf-8", newline="\n") as f:
        f.write(render_general(all_picked, used))
    print(f"\n通用版：{dest}")
    print(f"完成：{len(used)} 题材 + 1 通用")


if __name__ == "__main__":
    main()
