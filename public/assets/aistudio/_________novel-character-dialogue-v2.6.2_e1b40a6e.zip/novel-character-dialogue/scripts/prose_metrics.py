#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小说角色对话 · 正文质量机检（设计方案 模块 4 · v2.6.0）

对已写章节正文做可测量的质量对照：把正文指标与 `references/题材基准表.md`
（由 collect_prose_baseline.py 从语料库正文统计）逐项比较，输出偏离提示。

定位：**只出 advisory**。指标偏离不等于写错了，记录偏离与证据，由作者决定是否调整；
项目可把某项登记为规则后才具强制力（沿用 pending → canary → active 升级链）。

指标（与基准表一致）：
  单章字数 / 句长中位 / 段长中位 / 含对白段占比 / 纯对白段占比 /
  比喻密度 / 连续纯对白上限

用法：
  python scripts/prose_metrics.py <章节正文路径> [--genre 01-玄幻仙侠] [--baseline <基准表>]
  python scripts/prose_metrics.py <章节正文路径> --json          # 机器可读输出
  python scripts/prose_metrics.py selftest                        # 内置用例回归
"""

import io
import os
import re
import sys
import json
import argparse
import statistics

CJK = re.compile(r"[\u4e00-\u9fff]")
QUOTE_PAIR = re.compile(r"[\u201c\u300c]([^\u201d\u300d]{1,200})[\u201d\u300d]")
HAS_QUOTE = re.compile(r"[\u201c\u201d\u300c\u300d]")
PURE_DIALOGUE = re.compile(r"^[\u201c\u300c][^\u201d\u300d]*[\u201d\u300d][\u3002\uff01\uff1f\u2026\s]*$")
SIMILE = re.compile(r"(?:像|如同|宛如|仿佛|好似|犹如)")
SENT_SPLIT = re.compile(r"[。！？]")
CHAPTER_HEAD = re.compile(r"第[0-9一二三四五六七八九十百千]+章")

# ---- 情感维度（v2.6.1）：与 collect_prose_baseline.py 保持同一口径 ----
# 内心活动：视角人物当下的心理活动（合法；区别于"多年后他才明白"式作者已知识）
INNER = re.compile(
    r"(?:心想|暗道|暗想|心道|心中|心里|心底|内心|脑海里|脑中|寻思|琢磨|盘算|思忖|"
    r"念头|思索|疑惑|纳闷|不解|犹豫|迟疑|权衡|合计|暗自|自问|"
    r"明白过来|意识到|反应过来)"
)
# 即时情绪：事件发生后的第一反应（原作普遍做法，非抒情式铺陈）
EMO_IMMEDIATE = re.compile(
    r"(?:心中一|心头一|心里一|心底一|又[一-鿿]又[一-鿿]|"
    r"松了口气|松了一口气|大喜|狂喜|惊恐|惊喜|一惊|一喜|一怒|一急|一慌|"
    r"欣喜|忿忿|恼怒|愕然|骇然|释然|怅然|黯然|"
    r"长长地?吐了口气|倒吸了口?凉气)"
)

# 跨题材兜底基准（当无基准表且未指定题材时使用；来源于语料库 8 题材 40 本采样）
FALLBACK = {
    "单章字数": {"中位": 2756, "下限": 1800, "上限": 4200},
    "句长中位": {"中位": 28, "下限": 20, "上限": 34},
    "段长中位": {"中位": 44, "下限": 26, "上限": 70},
    "含对白段占比": {"中位": 35, "下限": 22, "上限": 62},
    "纯对白段占比": {"中位": 6, "下限": 0, "上限": 22},
    "比喻密度": {"中位": 1, "下限": 0, "上限": 4},
    "连续纯对白上限": {"中位": 10, "下限": 0, "上限": 16},
    # 情感维度（v2.6.1，来自语料库 8 题材实测的跨题材区间）
    "内心活动密度": {"中位": 1.0, "下限": 0.0, "上限": 4.1},
    "即时情绪密度": {"中位": 0.2, "下限": 0.0, "上限": 2.0},
    "台词长度中位": {"中位": 17, "下限": 4, "上限": 51},
    "长台词占比": {"中位": 28, "下限": 0, "上限": 74},
}

METRIC_ORDER = ["单章字数", "句长中位", "段长中位", "含对白段占比",
                "纯对白段占比", "比喻密度", "连续纯对白上限",
                "内心活动密度", "即时情绪密度", "台词长度中位", "长台词占比"]

# 单侧指标：只有超出上限才提示（值偏低属于好事，不报偏离）
UPPER_ONLY = {"纯对白段占比", "比喻密度", "连续纯对白上限"}
# v2.6.1 新增的内心活动/即时情绪/台词长度/长台词占比均为双侧：
# 偏低提示"情感干瘪"，偏高提示"心理过载/台词拖沓"。
# 这四项用更敏感的四分位阈值（见 compare 内说明）。
EMOTION_METRICS = {"内心活动密度", "即时情绪密度", "台词长度中位", "长台词占比"}
# 双侧指标：偏离下限与上限都提示
# 单章字数 / 句长中位 / 段长中位 / 含对白段占比

# 偏离提示语（越界时给出可操作方向）
ADVICE = {
    "单章字数": ("章内节拍可能未展开（起承转未铺开或收束过早）",
                 "可能存在未收束段落或节拍重复"),
    "句长中位": ("短句可能存在堆叠倾向（可考虑补承接句/复句）",
                 "长句可能偏多（可考虑拆句以推进节奏）"),
    "段长中位": ("段落可能偏碎（可考虑合并同镜头句）",
                 "段落可能偏长（可考虑按动作/对象切段）"),
    "含对白段占比": ("信息可能主要靠叙述承载（可考虑增加对话推进）",
                     "对白承载可能过载（可考虑补叙述与描写）"),
    "纯对白段占比": ("—",
                     "纯对白段偏多：对话可能未嵌入正文（可考虑补动作/身体/环境承接）"),
    "比喻密度": ("—", "喻词密度偏高（可考虑只留关键处的比喻）"),
    "连续纯对白上限": ("—", "存在较长连续对白（可考虑补承接或合并叙事）"),
    "内心活动密度": ("内心活动偏少：角色可能只有外在行为、缺内在反应；"
                 "参见 references/内心活动层.md 的合法边界与五种形态",
                 "内心活动偏多：检查是否出现连续多段心理描写（原作以 1 段为主）"),
    "即时情绪密度": ("即时情绪反应偏少：事件发生后角色缺少第一反应，读感可能平淡；"
                 "日常反应直陈更自然（如心中一喜/松了口气）",
                     "即时情绪偏多：检查是否事件密度不足而靠情绪词填充"),
    "台词长度中位": ("台词偏短：多为功能性短句，缺少承载型台词；"
                 "可参考台词三层承载（信息+态度+关系）",
                     "台词偏长：检查是否有大段独白未被打断"),
    "长台词占比": ("缺少承载型长台词：可为训诫/解释/辩论等场景补 2–4 处 30 字以上台词",
                   "长台词偏多：检查是否对话承担了过多叙述职能"),
}


def find_skill_root():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(here)


def split_paragraphs(text):
    out = []
    for p in text.split("\n"):
        p = p.strip()
        if not p or p.startswith("#") or p.startswith("|") or p.startswith(">"):
            continue
        if len(p) < 4:
            continue
        out.append(p)
    return out


def measure(text):
    """计算正文指标。返回 dict 或 None（正文过短）。"""
    paras = split_paragraphs(text)
    cjk = len(CJK.findall(text))
    if not paras or cjk < 200:
        return None

    plens = [len(p) for p in paras]
    sents = []
    for p in paras:
        sents += [s for s in SENT_SPLIT.split(p) if len(s.strip()) > 1]
    slens = [len(s) for s in sents] or [0]

    has_dlg = sum(1 for p in paras if HAS_QUOTE.search(p) and QUOTE_PAIR.search(p))
    pure = sum(1 for p in paras if PURE_DIALOGUE.match(p))
    simile = len(SIMILE.findall(text))

    run = best = 0
    for p in paras:
        if PURE_DIALOGUE.match(p):
            run += 1
            best = max(best, run)
        else:
            run = 0

    chs = []
    idx = [m.start() for m in CHAPTER_HEAD.finditer(text)]
    if idx:
        for i in range(len(idx) - 1):
            n = len(CJK.findall(text[idx[i]:idx[i + 1]]))
            if n > 300:
                chs.append(n)
        tail = len(CJK.findall(text[idx[-1]:]))
        if tail > 300:
            chs.append(tail)
    else:
        chs = [cjk]

    # ---- 情感维度（v2.6.1）----
    inner = len(INNER.findall(text))
    emo = len(EMO_IMMEDIATE.findall(text))
    quotes = [q for q in QUOTE_PAIR.findall(text) if 2 <= len(q) <= 300]
    qlens = sorted(len(q) for q in quotes)
    q_median = int(statistics.median(qlens)) if qlens else 0
    long_ratio = round(sum(1 for x in qlens if x >= 30) * 100.0 / len(qlens), 1) if qlens else 0.0

    return {
        "字数": cjk,
        "段数": len(paras),
        "单章字数": int(statistics.median(chs)) if chs else cjk,
        "句长中位": int(statistics.median(slens)),
        "内心活动密度": round(inner * 1000.0 / cjk, 2),
        "即时情绪密度": round(emo * 1000.0 / cjk, 2),
        "台词长度中位": q_median,
        "长台词占比": long_ratio,
        "段长中位": int(statistics.median(plens)),
        "含对白段占比": round(has_dlg * 100.0 / len(paras), 1),
        "纯对白段占比": round(pure * 100.0 / len(paras), 1),
        "比喻密度": round(simile * 1000.0 / cjk, 2),
        "连续纯对白上限": best,
    }


def parse_baseline(path):
    """解析 references/题材基准表.md：优先读分位阶梯（JSON 代码块），回退读区间表。"""
    table = {}
    ladders = {}
    if not path or not os.path.exists(path):
        return table, ladders
    try:
        text = io.open(path, encoding="utf-8").read()
    except Exception:
        return table, ladders

    # 1) 分位阶梯 JSON 块
    m = re.search(r"```json\s*\n(.*?)\n```", text, re.S)
    if m:
        try:
            raw = json.loads(m.group(1))
            for g, metrics in raw.items():
                ladder = {}
                for k, lad in metrics.items():
                    if isinstance(lad, dict) and "p50" in lad:
                        ladder[k] = {kk: float(vv) for kk, vv in lad.items()}
                if ladder:
                    ladders[g] = ladder
        except Exception:
            ladders = {}

    # 2) 区间表（兼容无阶梯的基准表）
    mapping = {"单章字数": 2, "句长中位": 3, "段长中位": 4,
               "含对白段占比": 5, "纯对白段占比": 6,
               "比喻密度": 7, "连续纯对白上限": 8}
    for line in text.split("\n"):
        line = line.strip()
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) < 9 or cells[0] in ("题材", "---") or set(cells[0]) <= set("-: "):
            continue
        genre = cells[0]
        if not re.match(r"^0[0-9]-", genre):
            continue
        vals = {}
        for k, i in mapping.items():
            if i >= len(cells):
                continue
            mm = re.match(r"^\s*(-?[\d.]+)\s*[（(]\s*(-?[\d.]+)\s*[–\-~]\s*(-?[\d.]+)\s*[）)]", cells[i])
            if mm:
                mid, lo, hi = float(mm.group(1)), float(mm.group(2)), float(mm.group(3))
                vals[k] = {"中位": mid, "下限": min(lo, hi), "上限": max(lo, hi)}
                continue
            m2 = re.match(r"^\s*(-?[\d.]+)\s*$", cells[i])
            if m2:
                v = float(m2.group(1))
                vals[k] = {"中位": v, "下限": v, "上限": v}
        if vals:
            table[genre] = vals
    return table, ladders


def percentile_of(value, ladder):
    """实测值在分位阶梯中的百分位位置（线性插值，返回 0–100）。"""
    pts = sorted((int(k[1:]), float(v)) for k, v in ladder.items())
    if not pts:
        return None
    if value <= pts[0][1]:
        return float(pts[0][0])
    if value >= pts[-1][1]:
        return float(pts[-1][0])
    for i in range(len(pts) - 1):
        (p1, v1), (p2, v2) = pts[i], pts[i + 1]
        if v1 <= value <= v2:
            if v2 == v1:
                return float(p2)
            frac = (value - v1) / (v2 - v1)
            return round(p1 + frac * (p2 - p1), 1)
    return None


def compare(metrics, base, ladder=None):
    """逐项比较，返回 findings 列表。

    优先用分位阶梯给出百分位位置（信息量更大）；无阶梯时回退区间二值判定。
    单侧指标（纯对白段/比喻/连续对白）只在偏高时提示。
    """
    findings = []
    for k in METRIC_ORDER:
        v = metrics.get(k)
        if v is None:
            continue
        lad = (ladder or {}).get(k)
        b = base.get(k) if base else None

        pct = percentile_of(v, lad) if lad else None

        if pct is not None:
            # 阈值分两档：
            #  · 文本形态类（字数/句长/段长/配比/修辞）：2%/98% 极端尾部。
            #    基准表混合了「书内章节波动」与「书间文风差异」，5%/95% 会对正常章节
            #    产生 13%–31% 的标记率（实测，未参与建表的书）。
            #  · 情感类（内心活动/即时情绪/台词长度/长台词占比）：25%/75% 四分位。
            #    理由：情感干瘪是本类指标的**主要失手方向**（实测技能原产出处于
            #    第 8.9–23.1 百分位仍被 2% 阈值放过），需更敏感；
            #    且这四项在原作中波动较小（内心活动 p25–p75 为 0.7–2.15‰），
            #    四分位带足以区分"有情感"与"干瘪"。
            if k in EMOTION_METRICS:
                if pct >= 75:
                    direction = "偏高"
                elif pct <= 25:
                    direction = "偏低"
                else:
                    continue
            else:
                if pct >= 98:
                    direction = "偏高"
                elif pct <= 2 and k not in UPPER_ONLY:
                    direction = "偏低"
                else:
                    continue
            findings.append({
                "指标": k, "实测": v,
                "百分位": pct,
                "语料中位": lad.get("p50"),
                "偏离": direction,
                "提示": ADVICE[k][1] if direction == "偏高" else ADVICE[k][0],
            })
            continue

        if not b:
            continue
        lo, hi, mid = b["下限"], b["上限"], b["中位"]
        if k in UPPER_ONLY:
            if v > hi:
                findings.append({"指标": k, "实测": v, "基准中位": mid, "参考区间": f"≤{hi}",
                                 "偏离": "偏高", "提示": ADVICE[k][1]})
            continue
        if v < lo:
            findings.append({"指标": k, "实测": v, "基准中位": mid, "参考区间": f"{lo}–{hi}",
                             "偏离": "偏低", "提示": ADVICE[k][0]})
        elif v > hi:
            findings.append({"指标": k, "实测": v, "基准中位": mid, "参考区间": f"{lo}–{hi}",
                             "偏离": "偏高", "提示": ADVICE[k][1]})
    return findings


def render(metrics, findings, base, ladder, genre, source):
    lines = []
    lines.append(f"# 正文质量机检 · {source}")
    lines.append("")
    basis = f"题材基准 {genre}（语料库章节级分布）" if genre else "跨题材兜底基准（未指定题材）"
    lines.append(f"- 基准来源：{basis}")
    lines.append(f"- 正文规模：{metrics['字数']} 字 / {metrics['段数']} 段")
    lines.append("")
    lines.append("## 一、指标实测与语料百分位")
    lines.append("")
    lines.append("| 指标 | 实测 | 语料中位 | 百分位 | 判定 |")
    lines.append("|---|---|---|---|---|")
    fm = {f["指标"]: f for f in findings}
    for k in METRIC_ORDER:
        v = metrics.get(k)
        if v is None:
            continue
        lad = (ladder or {}).get(k)
        b = (base or {}).get(k)
        if lad:
            pct = percentile_of(v, lad)
            mid = lad.get("p50")
            if k in fm:
                mark = f"⚠ {fm[k]['偏离']}（第 {pct} 百分位）"
            elif pct is not None and 25 <= pct <= 75:
                mark = "在语料常区间"
            else:
                mark = "在语料区间内"
            lines.append(f"| {k} | {v} | {mid} | {pct} | {mark} |")
        elif b:
            in_r = b["下限"] <= v <= b["上限"]
            if k in fm:
                mark = f"⚠ {fm[k]['偏离']}"
            elif k in UPPER_ONLY:
                mark = "未超限"
            else:
                mark = "在区间内" if in_r else "—"
            rng = f"≤{b['上限']}" if k in UPPER_ONLY else f"{b['下限']}–{b['上限']}"
            lines.append(f"| {k} | {v} | {b['中位']} | （区间 {rng}） | {mark} |")
        else:
            lines.append(f"| {k} | {v} | — | — | 无基准 |")
    lines.append("")
    lines.append("## 二、偏离提示（advisory）")
    lines.append("")
    if not findings:
        lines.append("全部指标落在语料分布的常见范围内。")
    else:
        for f in findings:
            if "百分位" in f:
                lines.append(f"- **{f['指标']}** 实测 {f['实测']}，处于参照语料第 **{f['百分位']}** 百分位"
                             f"（语料中位 {f['语料中位']}）：{f['提示']}")
            else:
                lines.append(f"- **{f['指标']}** 实测 {f['实测']}（{f['偏离']}，基准中位 {f['基准中位']}，"
                             f"参考区间 {f['参考区间']}）：{f['提示']}")
        lines.append("")
        lines.append("> 偏离不等于写错了。以上为观察提示，可记录进差异报告，由作者决定是否调整；")
        lines.append("> 项目登记为规则后才具强制力。")
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------- selftest

def selftest():
    ok, fail = 0, []

    def t(cond, name):
        nonlocal ok
        if cond:
            ok += 1
        else:
            fail.append(name)

    skill_root = find_skill_root()
    baseline_path = os.path.join(skill_root, "references", "题材基准表.md")
    table, ladders = parse_baseline(baseline_path)
    t(len(table) >= 8, f"基准表解析 {len(table)} 题材 ≥8")
    t(len(ladders) >= 8, f"分位阶梯解析 {len(ladders)} 题材 ≥8")

    if "01-玄幻仙侠" in table:
        b = table["01-玄幻仙侠"].get("句长中位")
        t(b is not None and b["下限"] < b["上限"], "玄幻句长区间可解析")
    if "01-玄幻仙侠" in ladders:
        lad = ladders["01-玄幻仙侠"].get("句长中位")
        t(lad is not None and lad.get("p50", 0) > 0, "玄幻句长分位阶梯可解析")
        # 百分位插值
        if lad:
            p_mid = percentile_of(lad["p50"], lad)
            t(p_mid is not None and 45 <= p_mid <= 55, f"中位值百分位={p_mid}")
            p_low = percentile_of(1, lad)
            t(p_low is not None and p_low <= 5, f"极低值百分位={p_low}")
            p_hi = percentile_of(9999, lad)
            t(p_hi is not None and p_hi >= 95, f"极高值百分位={p_hi}")

    # 短句流正文 → 句长偏低命中
    short = "\n".join([f"他说。她点头。风冷。灯灭。狗叫。他走。她留。天亮。" for _ in range(40)])
    m = measure(short)
    t(m is not None and m["句长中位"] <= 6, f"短句流句长中位={m and m['句长中位']}")

    # 长句正文 → 不偏低
    long_t = "\n".join([
        "他站在窗前看着外面那场从傍晚一直下到深夜的雨，想起三年前离家的那个同样潮湿的下午，"
        "那时候他还不知道这条路要走这么久，也不知道会在这样的夜里想起那盏一直亮着的灯。" * 3
        for _ in range(20)])
    ml = measure(long_t)
    t(ml is not None and ml["句长中位"] > 40, f"长句正文句长中位={ml and ml['句长中位']}")

    # 纯对白段占比：连续纯对白 → 偏高 + 连续上限
    pure_text = "\n".join([f"“这是今天的第{i}句话，说完了。”" for i in range(60)])
    mp = measure(pure_text)
    t(mp is not None and mp["纯对白段占比"] > 90, f"纯对白段占比={mp and mp['纯对白段占比']}")
    t(mp is not None and mp["连续纯对白上限"] >= 20, f"连续纯对白上限={mp and mp['连续纯对白上限']}")

    # 混合正文不误报
    mixed = []
    for i in range(20):
        mixed.append("他推开门，把伞靠在墙角，水顺着伞骨滴在地砖上。")
        mixed.append(f"“第{i}句台词。”他说完就转过身去，看着窗外。")
        mixed.append("风把窗帘掀起一角，又落回去。")
    mm = measure("\n".join(mixed))
    t(mm is not None and mm["纯对白段占比"] == 0, f"混合正文纯对白={mm and mm['纯对白段占比']}")

    # 比喻密度
    sim = "像" * 60 + "\n" + "他走在路上。" * 30
    ms = measure(sim)
    t(ms is not None and ms["比喻密度"] > 5, f"比喻密度={ms and ms['比喻密度']}")

    # compare：区间兜底模式（无阶梯）
    mid_m = {"句长中位": 28, "段长中位": 44, "含对白段占比": 35,
             "纯对白段占比": 6, "比喻密度": 1, "连续纯对白上限": 3, "单章字数": 2756}
    f = compare(dict(mid_m, 句长中位=1), FALLBACK, None)
    t(any(x["指标"] == "句长中位" for x in f), "compare 命中句长偏低")
    t(not any(x["指标"] == "段长中位" for x in f), "compare 区间内不误报")
    f2 = compare(dict(mid_m, 纯对白段占比=2, 比喻密度=0.5, 连续纯对白上限=1), FALLBACK, None)
    t(not any(x["指标"] in UPPER_ONLY for x in f2), "单侧指标偏低不误报")
    f3 = compare(dict(mid_m, 纯对白段占比=80, 比喻密度=9, 连续纯对白上限=40), FALLBACK, None)
    t(len([x for x in f3 if x["指标"] in UPPER_ONLY]) == 3, "单侧指标偏高全命中")

    # compare：分位阶梯模式
    if "01-玄幻仙侠" in ladders:
        lad = ladders["01-玄幻仙侠"]
        md = dict(mid_m)
        md["句长中位"] = int(lad.get("句长中位", {}).get("p1", 5)) - 20
        fa = compare(md, None, lad)
        t(any(x["指标"] == "句长中位" and "百分位" in x for x in fa), "阶梯模式命中极端低值")
        md2 = dict(mid_m)
        md2["句长中位"] = int(lad.get("句长中位", {}).get("p50", 30))
        fb = compare(md2, None, lad)
        t(not any(x["指标"] == "句长中位" for x in fb), "阶梯模式中位值不误报")

    # 兜底基准可用
    t(FALLBACK["句长中位"]["下限"] < FALLBACK["句长中位"]["上限"], "兜底基准区间有效")

    # 短文本返回 None
    t(measure("太短。") is None, "过短正文返回 None")

    # ---- v2.6.1 情感维度用例 ----
    # 1) 内心活动可检出
    inner_text = "\n".join([
        "他心里琢磨着这件事到底该怎么办，盘算了一遍又一遍。",
        "陈砚心中明白，这声音不是头一回了，疑惑也跟着上来。",
    ] * 30)
    mi = measure(inner_text)
    t(mi is not None and mi["内心活动密度"] > 5, f"内心活动密度可检出={mi and mi['内心活动密度']}")

    # 2) 无内心活动 → 密度 0
    flat = "\n".join(["他推开门，把伞靠在墙角，水顺着伞骨滴在地砖上，然后走了进去。"] * 40)
    mf = measure(flat)
    t(mf is not None and mf["内心活动密度"] == 0.0, f"无内心活动密度为0={mf and mf['内心活动密度']}")

    # 3) 即时情绪可检出
    emo_text = "\n".join([
        "他心中一喜，长长地吐了口气，终于松了口气。",
        "她心中一惊，又惊又喜，欣喜之感涌上来。",
    ] * 30)
    me = measure(emo_text)
    t(me is not None and me["即时情绪密度"] > 2, f"即时情绪密度可检出={me and me['即时情绪密度']}")

    # 4) 台词长度中位/长台词占比
    long_dlg = "\n".join(['“' + "这是一句很长的台词，用来测试承载量。" * 3 + '”'] * 20)
    ml = measure(long_dlg)
    t(ml is not None and ml["台词长度中位"] > 30, f"长台词长度中位={ml and ml['台词长度中位']}")
    t(ml is not None and ml["长台词占比"] > 80, f"长台词占比={ml and ml['长台词占比']}")

    short_dlg = "\n".join(['“嗯。”他应了一声，把东西放下，转身去看窗外那片雪。'] * 40)
    ms2 = measure(short_dlg)
    t(ms2 is not None and ms2["长台词占比"] == 0.0, f"短台词长台词占比为0={ms2 and ms2['长台词占比']}")

    # 5) 四分位阈值：情感指标在 p10 处应报偏低（而 2% 阈值不会）
    if "01-玄幻仙侠" in ladders:
        lad2 = ladders["01-玄幻仙侠"]
        if "内心活动密度" in lad2:
            p10v = lad2["内心活动密度"].get("p10", 0.4)
            md3 = dict(mid_m)
            for kk in pm_keys_for_test():
                md3.setdefault(kk, 0)
            md3["内心活动密度"] = p10v
            fc = compare(md3, None, lad2)
            t(any(x["指标"] == "内心活动密度" for x in fc),
              f"情感指标在p10处报偏低（{p10v}）")

    return ok, fail


def pm_keys_for_test():
    """compare() 需要的指标键（补零占位，避免 KeyError）。"""
    return METRIC_ORDER


def main():
    ap = argparse.ArgumentParser(description="正文质量机检（对照题材基准表，只出 advisory）")
    ap.add_argument("target", help="章节正文路径，或 selftest")
    ap.add_argument("--genre", default=None, help="题材目录名，如 01-玄幻仙侠")
    ap.add_argument("--baseline", default=None, help="基准表路径（默认技能内 references/题材基准表.md）")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    args = ap.parse_args()

    if args.target == "selftest":
        ok, fail = selftest()
        print(f"prose_metrics selftest：{ok} 通过 / {len(fail)} 失败")
        for f in fail:
            print("  FAIL:", f)
        sys.exit(0 if not fail else 1)

    if not os.path.exists(args.target):
        print(f"[错误] 找不到正文文件：{args.target}")
        sys.exit(1)

    text = io.open(args.target, encoding="utf-8").read()
    m = measure(text)
    if m is None:
        print("[提示] 正文过短（<200 汉字或无有效段落），无法机检。")
        sys.exit(0)

    bpath = args.baseline or os.path.join(find_skill_root(), "references", "题材基准表.md")
    table, ladders = parse_baseline(bpath)
    base = table.get(args.genre) if args.genre else None
    ladder = ladders.get(args.genre) if args.genre else None
    genre_used = args.genre if (base or ladder) else None
    if not base and not ladder:
        base = FALLBACK          # 未指定题材或基准缺失：跨题材兜底

    findings = compare(m, base, ladder)

    if args.json:
        print(json.dumps({"指标": m, "偏离": findings,
                          "基准": genre_used or "跨题材兜底"}, ensure_ascii=False, indent=2))
    else:
        print(render(m, findings, base, ladder, genre_used, os.path.basename(args.target)))

    sys.exit(0)


if __name__ == "__main__":
    main()
