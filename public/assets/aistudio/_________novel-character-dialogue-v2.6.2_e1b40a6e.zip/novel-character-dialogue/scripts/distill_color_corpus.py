#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小说角色对话 · 六色语料扩展示例库（设计方案 模块 6 L3 · v2.6.0）

知识库正文带**六色标注体系**：
  蓝-环境 / 绿-人物 / 橙-修辞 / 紫-叙事技巧 / 红-剧情爽点 / 黄-对白情绪

原技能只蒸馏了「黄-对白情绪」一色。本脚本把其余五色也接入，
并通过标注索引的 `C{n}` 锚点**回定位到正文原文**，抽出所在自然段作为段落级示例。

为什么需要段落级示例：
  方法卡现有示例多为单句台词（R 原文引用），缺少"这段怎么写"的完整示范。
  段落级示例能同时展示句式、节奏、承接与信息密度，是更接近成文的参照。

产物：`references/叙事示例库-<题材>.md`（按六色分组，每条含锚点与所在段落）
      `references/叙事示例库-通用.md`（跨题材汇总）

只读语料库；不修改源文件。

用法：
  python scripts/distill_color_corpus.py --kb "<语料库路径>" --genre 01-玄幻仙侠 --books 3
  python scripts/distill_color_corpus.py --kb "<语料库路径>" --books 2
"""

import io
import os
import re
import sys
import argparse

COLORS = [
    ("蓝-环境", "环境描写：氛围、空间、天气与处境的呈现"),
    ("绿-人物", "人物刻画：形象、神态、动作与性格呈现"),
    ("橙-修辞", "修辞手法：比喻、排比、白描、通感"),
    ("紫-叙事技巧", "叙事技巧：视角、时间、信息释放、结构安排"),
    ("红-剧情爽点", "剧情爽点：冲突、反转、升级与情绪兑现"),
    ("黄-对白情绪", "对白与情绪：台词设计、情绪承载"),
]

DEFAULT_GENRES = [
    "01-玄幻仙侠", "02-都市职场", "03-历史架空", "04-科幻末世",
    "05-悬疑灵异", "06-奇幻西幻", "07-游戏竞技", "08-言情古言",
]

# 单条示例的段落上限（避免把整场戏都吞进来）
MAX_PARA = 320
MIN_SNIPPET = 12


def find_skill_root():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(here)


def _is_book_dir(name):
    if name.startswith(".") or name.startswith("_"):
        return False
    if name.endswith(".md"):
        return False
    return name not in ("__pycache__", "audit_out", "backups")


def load_volume_texts(book_dir, max_volumes=4):
    """加载正文卷文件用于锚点回定位。

    锚点索引覆盖全书（从第 1 章起），因此必须包含**首卷**，
    否则大量 C{n} 锚点无法定位（实测只取中段卷时定位率显著偏低）。
    余下名额取中段卷，兼顾后期的文风。
    """
    vdir = os.path.join(book_dir, "01-小说正文", "正文分卷")
    if not os.path.isdir(vdir):
        return []
    files = [f for f in sorted(os.listdir(vdir))
             if f.endswith(".md") and "占位" not in f and "索引" not in f]
    if not files:
        return []
    mid = len(files) // 2
    order = [0, mid]                    # 首卷 + 中段卷
    for off in range(1, max_volumes):
        if mid + off < len(files):
            order.append(mid + off)
    picks = []
    for i in order:
        if 0 <= i < len(files) and files[i] not in picks:
            picks.append(files[i])
        if len(picks) >= max_volumes:
            break
    out = []
    for f in picks:
        try:
            out.append((f, io.open(os.path.join(vdir, f), encoding="utf-8").read()))
        except Exception:
            continue
    return out


def parse_color_index(book_dir):
    """解析 标注索引_六色.md → {颜色: [摘录, ...]}。"""
    p = os.path.join(book_dir, "01-小说正文", "标注索引_六色.md")
    if not os.path.exists(p):
        return {}
    try:
        t = io.open(p, encoding="utf-8").read()
    except Exception:
        return {}
    out = {}
    for color, _ in COLORS:
        m = re.search(r"^## " + re.escape(color) + r"\n(.*?)(?=^## |\Z)", t, re.S | re.M)
        if not m:
            continue
        items = []
        for row in m.group(1).split("\n"):
            if not row.startswith("| C") or "C{n}" in row:
                continue
            cells = [c.strip() for c in row.strip("|").split("|")]
            # 行格式：| C{n} | 摘录 |  → strip 后为 [锚点, 摘录] 两项
            if len(cells) >= 2:
                snip = cells[1].rstrip("…").strip()
                if len(snip) >= MIN_SNIPPET:
                    items.append((cells[0], snip))
        out[color] = items
    return out


def locate_paragraph(volumes, snippet):
    """用摘录前缀在正文里定位，返回所在自然段。"""
    key = snippet[:24]
    if len(key) < 8:
        return None
    for fname, text in volumes:
        i = text.find(key)
        if i < 0:
            continue
        s = text.rfind("\n", 0, i) + 1
        e = text.find("\n", i)
        if e < 0:
            e = len(text)
        para = text[s:e].strip()
        if not para:
            continue
        if len(para) > MAX_PARA:
            para = para[:MAX_PARA].rstrip() + "……"
        return fname, para
    return None


def collect_book(book_dir, per_color=4):
    """单书：六色各取若干条，附正文段落。"""
    index = parse_color_index(book_dir)
    if not index:
        return None
    volumes = load_volume_texts(book_dir)
    if not volumes:
        return None
    out = {}
    for color, _desc in COLORS:
        items = index.get(color, [])
        got = []
        for anchor, snip in items:
            if len(got) >= per_color:
                break
            loc = locate_paragraph(volumes, snip)
            para = loc[1] if loc else snip
            got.append({"anchor": anchor, "snippet": snip, "para": para,
                        "located": bool(loc)})
        if got:
            out[color] = got
    return out


def collect_genre(kb, genre, books, per_color):
    gdir = os.path.join(kb, genre)
    if not os.path.isdir(gdir):
        return {}
    names = sorted(b for b in os.listdir(gdir)
                   if _is_book_dir(b) and os.path.isdir(os.path.join(gdir, b)))
    result = {}
    picked = 0
    for b in names:
        if picked >= books:
            break
        got = collect_book(os.path.join(gdir, b), per_color)
        if got:
            result[b] = got
            picked += 1
    return result


def render_genre(genre, books_data):
    lines = []
    total = sum(len(v) for b in books_data.values() for v in b.values())
    lines.append(f"# 叙事示例库 · {genre}（六色语料段落级示例）")
    lines.append("")
    lines.append("> 来源：知识库正文的六色标注索引（蓝-环境/绿-人物/橙-修辞/紫-叙事技巧/红-剧情爽点/黄-对白情绪），")
    lines.append("> 通过 `C{n}` 锚点回定位到正文原文，抽取所在自然段。")
    lines.append(f"> 覆盖 {len(books_data)} 本 / {total} 条段落级示例。")
    lines.append("")
    lines.append("**定位**：示例是**参照写法**，展示该题材在相应维度上「写出来是什么样」，")
    lines.append("不是必须模仿的模板。原技能此前只蒸馏了黄-对白情绪一色，本库补齐其余五色。")
    lines.append("")
    lines.append("---")
    lines.append("")

    for color, desc in COLORS:
        lines.append(f"## {color} · {desc}")
        lines.append("")
        any_row = False
        for book, data in books_data.items():
            if color not in data:
                continue
            any_row = True
            lines.append(f"### 《{book}》")
            lines.append("")
            for item in data[color]:
                mark = "" if item["located"] else "（未在正文定位，显示索引摘录）"
                lines.append(f"- **{item['anchor']}**{mark}")
                lines.append(f"  > {item['para']}")
                lines.append("")
        if not any_row:
            lines.append("（本题材该色无样本）")
            lines.append("")

    lines.append("---")
    lines.append("")
    lines.append("## 使用说明")
    lines.append("")
    lines.append("1. 写环境段落前读「蓝-环境」，看该题材常见的环境承载方式。")
    lines.append("2. 写人物出场/反应前读「绿-人物」，看形象与动作如何呈现。")
    lines.append("3. 修辞拿不准时读「橙-修辞」，对照该题材的密度与喻体习惯。")
    lines.append("4. 结构安排（视角、时间、信息释放）参考「紫-叙事技巧」。")
    lines.append("5. 爽点与情绪兑现参考「红-剧情爽点」。")
    lines.append("6. 台词与情绪承载参考「黄-对白情绪」，配合 `对话蒸馏方法卡/`。")
    lines.append("")
    lines.append("> 全部示例可用 `scripts/prose_metrics.py` 的指标思路反向验证：")
    lines.append("> 自己写的段落，各项指标是否落在该题材参照语料的分布内。")
    lines.append("")
    return "\n".join(lines)


def render_general(all_data, genres_used):
    lines = []
    lines.append("# 叙事示例库 · 跨题材（六色语料段落级示例）")
    lines.append("")
    lines.append("> 来源：知识库六色标注索引，按题材见各 `叙事示例库-<题材>.md`。")
    lines.append(f"> 覆盖题材：{'、'.join(genres_used)}")
    lines.append("")
    lines.append("**定位**：跨题材示例用于对照「同一维度不同题材怎么写」，均为参照写法而非模板。")
    lines.append("")
    lines.append("---")
    lines.append("")

    for color, desc in COLORS:
        lines.append(f"## {color} · {desc}")
        lines.append("")
        shown = 0
        for genre, books_data in all_data.items():
            for book, data in books_data.items():
                if color not in data or shown >= 6:
                    continue
                for item in data[color][:1]:
                    lines.append(f"- **{genre} · {item['anchor']} · 《{book}》**")
                    lines.append(f"  > {item['para']}")
                    lines.append("")
                    shown += 1
        if shown == 0:
            lines.append("（无色样本）")
            lines.append("")

    lines.append("---")
    lines.append("")
    lines.append("## 六色与技能资产的对应")
    lines.append("")
    lines.append("| 色 | 维度 | 对应技能资产 |")
    lines.append("|---|---|---|")
    lines.append("| 蓝-环境 | 环境描写 | `叙事层生成契约` 第三节（段落承载）、D3 环境印证 |")
    lines.append("| 绿-人物 | 人物刻画 | `七维角色卡清单` D1/D4/D6 |")
    lines.append("| 橙-修辞 | 修辞手法 | `prose_metrics.py` 比喻密度指标 |")
    lines.append("| 紫-叙事技巧 | 视角与结构 | `叙事层生成契约` 第四节（视角与信息节流） |")
    lines.append("| 红-剧情爽点 | 冲突与兑现 | `创作方法论-*.md` 情节与节奏 |")
    lines.append("| 黄-对白情绪 | 台词与情绪 | `对话蒸馏方法卡/` + `工作流-对话成文承接.md` |")
    lines.append("")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="六色语料扩展示例库（补齐黄以外的五色）")
    ap.add_argument("--kb", required=True, help="语料库根目录")
    ap.add_argument("--genre", action="append", default=None, help="指定题材（可重复）")
    ap.add_argument("--books", type=int, default=2, help="每题材取几本（默认 2）")
    ap.add_argument("--per-color", type=int, default=4, help="每色每本取几条（默认 4）")
    ap.add_argument("--out-dir", default=None, help="输出目录（默认 <技能根>/references）")
    args = ap.parse_args()

    kb = os.path.abspath(args.kb)
    if not os.path.isdir(kb):
        print(f"[错误] 语料库目录不存在：{kb}")
        sys.exit(1)
    genres = args.genre or [g for g in DEFAULT_GENRES if os.path.isdir(os.path.join(kb, g))]
    if not genres:
        print(f"[错误] {kb} 下未找到题材目录")
        sys.exit(1)

    out_dir = args.out_dir or os.path.join(find_skill_root(), "references")
    os.makedirs(out_dir, exist_ok=True)

    all_data, used = {}, []
    print(f"采集六色示例：{kb}")
    for g in genres:
        data = collect_genre(kb, g, args.books, args.per_color)
        if not data:
            print(f"  {g}：无六色索引或无正文（跳过）")
            continue
        all_data[g] = data
        used.append(g)
        n = sum(len(v) for b in data.values() for v in b.values())
        dest = os.path.join(out_dir, f"叙事示例库-{g}.md")
        with io.open(dest, "w", encoding="utf-8", newline="\n") as f:
            f.write(render_genre(g, data))
        print(f"  {g}：{len(data)} 本 / {n} 条 -> {os.path.basename(dest)}")

    if not all_data:
        print("[错误] 未采到任何示例。")
        sys.exit(1)

    dest = os.path.join(out_dir, "叙事示例库-通用.md")
    with io.open(dest, "w", encoding="utf-8", newline="\n") as f:
        f.write(render_general(all_data, used))
    print(f"\n通用版：{dest}")
    print(f"完成：{len(used)} 题材 + 1 通用")


if __name__ == "__main__":
    main()
