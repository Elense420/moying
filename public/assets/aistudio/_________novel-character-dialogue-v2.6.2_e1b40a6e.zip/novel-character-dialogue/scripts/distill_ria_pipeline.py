#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小说角色对话 · RIA 蒸馏原料层（设计方案升级三 / G7）

三层原料策略（按成本递增）：
  L1  读知识库每书 06-深度蒸馏.md 的黄段精选（12 条/书，带 C{n} 锚点）——零成本
  L2  读知识库每书 标注索引_六色.md 的黄段 30 条样本——零成本
  L3  回 G:/知识库/_结构外置/原文txt/ 按源 txt 序号定向重抽——高成本（8 本乱码书
      与 13 本未拆卷书必须走此路径）

产物：RIA 原料包（带 C{n} 锚点的对话样本集），供模型层聚类成方法卡。

用法：
  # L1+L2 免重抽（推荐冒烟/小批量）
  python scripts/distill_ria_pipeline.py --kb "G:/知识库/网文TOP500" --genre 02-都市职场 --sample 5 --use-l1
  # L3 全量重抽（含乱码书修复后重蒸）
  python scripts/distill_ria_pipeline.py --kb "G:/知识库/网文TOP500" --genre 02-都市职场 --full \
      --raw-txt "G:/知识库/_结构外置/原文txt"
"""

import os
import re
import sys
import glob
import json
import random
import argparse

QUOTE_PAIR = re.compile(r"[“「『]([^”」』]{1,100})[”」』]")
HAS_QUOTE = re.compile(r"[“”「」『』]")
CJK_JUNK = re.compile(r"[^\x20-\x7e\u2000-\u206f\u3000-\u303f\u4e00-\u9fff\uff00-\uffef]")
# 06-深度蒸馏 黄段表行：| C{n} | 摘录 |
C_ANCHOR_ROW = re.compile(r"^\|\s*C(\d+)\s*\|\s*(.+?)\s*\|?\s*$", re.M)
# 标注索引_六色.md 同格式
META_NAME = re.compile(r"(占位|说明|进度|总表|索引|README|目录|MOC)", re.I)


def find_skill_root():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(here)


def clean_text(s):
    s = CJK_JUNK.sub("", s)
    return re.sub(r"[ \t]{2,}", " ", s).strip()


def is_degraded(text):
    """判定一段文本是否编码降级（垃圾字符占比）。"""
    if not text:
        return True
    return len(clean_text(text)) < max(8, int(len(text) * 0.5))


# ---------------------------------------------------------------- L1：06-深度蒸馏 黄段精选

def read_l1(book_dir):
    """读 02-仓颉小说蒸馏/06-深度蒸馏.md 的黄段精选（带 C{n} 锚点）。返回 [(C锚点, 摘录), ...]"""
    path = os.path.join(book_dir, "02-仓颉小说蒸馏", "06-深度蒸馏.md")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    rows = []
    # 定位黄-对白情绪小节
    m = re.search(r"黄[\-—].*?对白.*?\n(.*?)(?=\n##|\Z)", text, re.S)
    section = m.group(1) if m else text
    for cm in C_ANCHOR_ROW.finditer(section):
        c_no, excerpt = cm.group(1), cm.group(2)
        excerpt = excerpt.rstrip("…").strip()
        if HAS_QUOTE.search(excerpt) and not is_degraded(excerpt):
            rows.append((f"C{c_no}", excerpt))
    return rows


# ---------------------------------------------------------------- L2：标注索引_六色.md

def read_l2(book_dir):
    """读 01-小说正文/标注索引_六色.md 的黄段 30 条样本（带 C{n} 锚点）。"""
    path = os.path.join(book_dir, "01-小说正文", "标注索引_六色.md")
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    rows = []
    m = re.search(r"黄[\-—].*?对白.*?\n(.*?)(?=\n##|\Z)", text, re.S)
    section = m.group(1) if m else text
    for cm in C_ANCHOR_ROW.finditer(section):
        c_no, excerpt = cm.group(1), cm.group(2)
        excerpt = excerpt.rstrip("…").strip()
        if HAS_QUOTE.search(excerpt) and not is_degraded(excerpt):
            rows.append((f"C{c_no}", excerpt))
    return rows


# ---------------------------------------------------------------- 白描原料：锚点回正文定位 ±N 行

def _quote_fragment(excerpt, n=12):
    """从黄段摘录提取可定位的引文片段（前 n 字）。"""
    m = QUOTE_PAIR.search(excerpt)
    frag = m.group(1) if m else excerpt
    return frag[:n].strip()


def locate_context(book_dir, rows, ctx_lines=3, max_hits_per_book=8):
    """把 L1/L2 锚点样本回正文分卷定位，抽取情绪点前后 ctx_lines 行的段落块。

    定位策略：① 按 C{n} → `## 第n章` 标题切分定位章；② 章内用引文片段模糊匹配；
    ③ 章定位失败时全卷模糊匹配（降级）。返回 (blocks, n_hit, n_miss)。
    """
    parts = [p for p in glob.glob(os.path.join(book_dir, "**", "正文分卷", "*.md"), recursive=True)
             if not META_NAME.search(os.path.basename(p))]
    if not parts:
        return [], 0, len(rows)
    # 预读全部卷文件文本（按卷缓存）
    volumes = []
    for p in parts:
        try:
            with open(p, "r", encoding="utf-8") as f:
                volumes.append((p, f.read()))
        except Exception:
            continue

    blocks, n_hit, n_miss = [], 0, 0
    seen = set()
    for anchor, excerpt in rows:
        frag = _quote_fragment(excerpt)
        if len(frag) < 4:
            n_miss += 1
            continue
        ch_no = anchor.lstrip("C")
        hit = None
        for vpath, vtext in volumes:
            # ① 章定位
            scope = vtext
            if ch_no.isdigit():
                m = re.search(rf"^##\s*第{ch_no}章[^\n]*$", vtext, re.M)
                if m:
                    nxt = re.search(r"^##\s*第\d+章", vtext[m.end():], re.M)
                    scope = vtext[m.end(): m.end() + nxt.start()] if nxt else vtext[m.end():]
            # ② 片段匹配
            idx = scope.find(frag)
            if idx == -1:
                continue
            # ③ 抽 ±ctx_lines 行
            line_start = scope.rfind("\n", 0, idx)
            lines = scope[:idx].count("\n")
            all_lines = scope.splitlines()
            center = lines if line_start != -1 else 0
            lo, hi = max(0, center - ctx_lines), min(len(all_lines), center + ctx_lines + 1)
            seg = "\n".join(l for l in (clean_text(x) for x in all_lines[lo:hi]) if l)
            key = frag + str(center)
            if key in seen:
                break
            seen.add(key)
            hit = (vpath, anchor, seg)
            break
        if hit:
            n_hit += 1
            blocks.append(hit)
            if len(blocks) >= max_hits_per_book:
                break
        else:
            n_miss += 1
    return blocks, n_hit, n_miss


# ---------------------------------------------------------------- L3：外置原文 txt 重抽

def read_l3(book_dir, raw_txt_root, book_name, max_lines=60):
    """按 00_阅读进度与标注总表 的源 txt 序号，回外置原文 txt 重抽对话行。"""
    idx_path = os.path.join(book_dir, "01-小说正文", "00_阅读进度与标注总表.md")
    src_no = None
    if os.path.exists(idx_path):
        with open(idx_path, "r", encoding="utf-8") as f:
            t = f.read()
        m = re.search(r"源[txtTXT]*[序号编号]*[：:]\s*(\d+)", t)
        if m:
            src_no = m.group(1)
    # 外置原文命名：NNN_《书名》（…）作者：XX.txt
    cand = glob.glob(os.path.join(raw_txt_root, f"*《{book_name}》*.txt"))
    if not cand and src_no:
        cand = glob.glob(os.path.join(raw_txt_root, f"{src_no}_*.txt"))
    if not cand:
        return []
    rows = []
    try:
        with open(cand[0], "r", encoding="utf-8", errors="ignore") as f:
            for raw in f:
                ln = clean_text(raw)
                if not ln or not HAS_QUOTE.search(ln) or not (6 <= len(ln) <= 300):
                    continue
                qlen = sum(len(m.group(1)) for m in QUOTE_PAIR.finditer(ln))
                if qlen < 4 or is_degraded(raw):
                    continue
                rows.append(("RAW", ln))
                if len(rows) >= max_lines:
                    break
    except Exception:
        return []
    return rows


# ---------------------------------------------------------------- 主流程

def main():
    ap = argparse.ArgumentParser(description="RIA 蒸馏原料层（L1/L2/L3）")
    ap.add_argument("--kb", required=True)
    ap.add_argument("--genre", action="append", default=[], help="题材目录名（可多次）")
    ap.add_argument("--all-genres", action="store_true")
    ap.add_argument("--sample", type=int, default=5, help="每题材抽几本")
    ap.add_argument("--use-l1", action="store_true", help="只用 L1+L2（免重抽）")
    ap.add_argument("--full", action="store_true", help="启用 L3 外置原文重抽")
    ap.add_argument("--context", type=int, default=0,
                    help="白描原料模式：锚点样本回正文定位，抽取情绪点前后 N 行段落块（0=关闭）")
    ap.add_argument("--context-hits", type=int, default=8, help="每本书最多输出的上下文块数")
    ap.add_argument("--raw-txt", default=r"G:/知识库/_结构外置/原文txt", help="外置原文根目录")
    ap.add_argument("--out", default=os.path.join(find_skill_root(), "distill_ria"))
    args = ap.parse_args()

    kb = os.path.abspath(args.kb)
    os.makedirs(args.out, exist_ok=True)

    if args.all_genres:
        genres = sorted(d for d in os.listdir(kb)
                        if os.path.isdir(os.path.join(kb, d)) and not d.startswith(".")
                        and not d.startswith("00") and "索引" not in d)
    else:
        genres = [g for g in args.genre if os.path.isdir(os.path.join(kb, g))]
    if not genres:
        print("[错误] 无有效题材目录"); sys.exit(1)

    rng = random.Random(42)
    for genre in genres:
        genre_dir = os.path.join(kb, genre)
        books = sorted(d for d in os.listdir(genre_dir)
                       if os.path.isdir(os.path.join(genre_dir, d)) and not d.startswith("."))
        sample = books if len(books) <= args.sample else rng.sample(books, args.sample)

        out_lines = [f"# {genre} · RIA 对话原料包", "",
                     f"> 来源：{kb} ／ 抽样 {len(sample)} 本 ／ 原料层："
                     + ("L1+L2（免重抽）" if args.use_l1 else "L1+L2+L3（含外置原文重抽）"),
                     "> 每条样本带 C{n} 锚点（或 RAW=外置原文行）。供模型层聚类成 RIA 方法卡。", ""]
        total = 0
        ctx_blocks_all, ctx_hit_total, ctx_miss_total = [], 0, 0
        for book in sample:
            book_dir = os.path.join(genre_dir, book)
            rows = []
            l1 = read_l1(book_dir)
            l2 = read_l2(book_dir)
            rows.extend(l1)
            rows.extend(l2)
            if args.full and not args.use_l1:
                l3 = read_l3(book_dir, args.raw_txt, book)
                rows.extend(l3)
            if not rows:
                out_lines.append(f"## 《{book}》\n<!-- 无可用样本（L1/L2 为空且未启用 L3）-->\n")
                continue
            out_lines.append(f"## 《{book}》")
            seen = set()
            for anchor, excerpt in rows:
                key = clean_text(excerpt)[:50]
                if key in seen:
                    continue
                seen.add(key)
                out_lines.append(f"- 【{anchor}】{excerpt}")
                total += 1
            out_lines.append("")
            # 白描原料模式：锚点回正文定位，抽 ±N 行段落块
            if args.context > 0:
                blocks, n_hit, n_miss = locate_context(book_dir, rows, args.context,
                                                       args.context_hits)
                ctx_hit_total += n_hit
                ctx_miss_total += n_miss
                ctx_blocks_all.append((book, blocks))
            print(f"[{genre}] 《{book}》：L1 {len(l1)} + L2 {len(l2)}"
                  + (f" + L3 {len(rows)-len(l1)-len(l2)}" if args.full else "") + f" = {len(seen)} 条")
        out_file = os.path.join(args.out, f"{genre}_RIA原料.md")
        with open(out_file, "w", encoding="utf-8") as f:
            f.write("\n".join(out_lines))
        # 白描上下文产物独立成文件
        if args.context > 0:
            ctx_lines_out = [f"# {genre} · 白描上下文原料（情绪点 ±{args.context} 行）", "",
                             f"> 锚点回正文定位；定位成功 {ctx_hit_total} / 失败 {ctx_miss_total}"
                             f"（成功率 {ctx_hit_total / max(1, ctx_hit_total + ctx_miss_total) * 100:.0f}%）",
                             "> 供 D 类白描方法卡取 R 引用。", ""]
            for book, blocks in ctx_blocks_all:
                if not blocks:
                    continue
                ctx_lines_out.append(f"## 《{book}》")
                for vpath, anchor, seg in blocks:
                    rel = os.path.relpath(vpath, kb).replace("\\", "/")
                    ctx_lines_out.append(f"### 【{anchor}】")
                    ctx_lines_out.append(f"<!-- provenance: {rel} -->")
                    ctx_lines_out.append("```")
                    ctx_lines_out.append(seg)
                    ctx_lines_out.append("```")
                    ctx_lines_out.append("")
            ctx_file = os.path.join(args.out, f"{genre}_白描上下文.md")
            with open(ctx_file, "w", encoding="utf-8") as f:
                f.write("\n".join(ctx_lines_out))
            print(f"[{genre}] 白描上下文：{ctx_file} · 定位成功率 "
                  f"{ctx_hit_total / max(1, ctx_hit_total + ctx_miss_total) * 100:.0f}%")
        print(f"[{genre}] 原料包：{out_file} · 总样本 {total} 条")


if __name__ == "__main__":
    main()
